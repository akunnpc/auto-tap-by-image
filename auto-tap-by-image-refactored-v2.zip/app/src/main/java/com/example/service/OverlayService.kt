package com.example.service

import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.util.Log
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import com.example.data.AppDatabase
import com.example.data.ProfileRepository
import com.example.data.TargetImage
import com.example.service.ScreenCaptureService.Companion.ACTION_PAUSE_TAPPING
import com.example.service.ScreenCaptureService.Companion.ACTION_START_TAPPING
import com.example.service.ScreenCaptureService.Companion.ACTION_STOP
import com.example.service.ScreenCaptureService.Companion.EXTRA_PROFILE_ID
import com.example.ui.overlay.HighlightView
import com.example.ui.overlay.TargetPinView
import com.example.util.AppLogger
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class OverlayService : Service() {

    private val job = SupervisorJob()
    private val serviceScope = CoroutineScope(Dispatchers.Main + job)

    private var windowManager: WindowManager? = null
    private var overlayView: FrameLayout? = null
    private var layoutParams: WindowManager.LayoutParams? = null

    private var isExpanded = false
    private var arePinsVisible = true
    private var currentProfileId: Long = -1L
    private lateinit var repository: ProfileRepository
    private lateinit var pointConfigDialog: PointConfigDialogController

    // Floating Target Pins
    private val activePins = mutableListOf<TargetPinView>()

    // programmatically created subviews
    private var collapsedLayout: LinearLayout? = null
    private var expandedLayout: LinearLayout? = null
    private var playPauseButton: ImageView? = null
    private var togglePinsButton: ImageView? = null
    private var statusText: TextView? = null
    private var profileNameText: TextView? = null
    private var tapCountText: TextView? = null
    private var highlightView: HighlightView? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val db = AppDatabase.getDatabase(this)
        repository = ProfileRepository(db.autoTapDao())
        pointConfigDialog = PointConfigDialogController(
            context = this,
            repository = repository,
            scope = serviceScope,
            onDismiss = { }
        )

        // Initialize the full-screen transparent highlighting overlay
        val layoutType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }
        val highlightParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            layoutType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or 
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or 
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        highlightView = HighlightView(this)
        windowManager?.addView(highlightView, highlightParams)

        createFloatingWidget()
        observeServiceState()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val profileName = intent?.getStringExtra(EXTRA_PROFILE_NAME) ?: "No Profile"
        profileNameText?.text = profileName
        val profileId = intent?.getLongExtra(EXTRA_PROFILE_ID, -1L) ?: -1L
        if (profileId != -1L) {
            currentProfileId = profileId
            loadExistingPointTargets(profileId)
        }
        return START_NOT_STICKY
    }

    private fun loadExistingPointTargets(profileId: Long) {
        serviceScope.launch(Dispatchers.IO) {
            var data = repository.getProfileWithTargetsDirect(profileId)
            if (data != null && data.targets.isEmpty()) {
                val dm = resources.displayMetrics
                val defaultTarget = TargetImage(
                    profileId = profileId,
                    name = "Titik 1",
                    filePath = "",
                    threshold = 0.8f,
                    delayAfterTapMs = 500L,
                    maxTaps = 0,
                    priority = 0,
                    targetType = "POINT",
                    pointX = dm.widthPixels / 2f,
                    pointY = dm.heightPixels / 2f,
                    actionType = "TAP"
                )
                repository.insertTargetImage(defaultTarget)
                data = repository.getProfileWithTargetsDirect(profileId)
            }
            withContext(Dispatchers.Main) {
                // Clear active pins
                clearAllPins()
                val pointTargets = data?.targets?.filter { it.targetType == "POINT" } ?: emptyList()
                pointTargets.sortedBy { it.priority }.forEachIndexed { index, target ->
                    addPinViewToScreen(target.pointX, target.pointY, index + 1, target.id)
                }
            }
        }
    }

    private fun clearAllPins() {
        activePins.forEach { pin ->
            try { windowManager?.removeView(pin) } catch (e: Exception) {}
        }
        activePins.clear()
    }

    private fun addPinViewToScreen(x: Float, y: Float, stepNumber: Int, targetId: Long): TargetPinView {
        val wm = windowManager ?: return TargetPinView(this, stepNumber, targetId, { _, _, _ -> }, {})
        val pinView = TargetPinView(
            context = this,
            stepNumber = stepNumber,
            targetId = targetId,
            onPositionChanged = { pin, newX, newY ->
                serviceScope.launch(Dispatchers.IO) {
                    val data = repository.getProfileWithTargetsDirect(currentProfileId)
                    val existingTarget = data?.targets?.find { it.id == pin.targetId }
                    if (existingTarget != null) {
                        repository.updateTargetImage(existingTarget.copy(pointX = newX, pointY = newY))
                        AppLogger.log("Titik Sentuh #${pin.stepNumber} dipindah ke (${newX.toInt()}, ${newY.toInt()})")
                    }
                }
            },
            onPinClicked = { pin ->
                showPinConfigDialog(pin)
            }
        )

        // Set initial coordinates
        val pinSize = (48 * resources.displayMetrics.density).toInt()
        pinView.layoutParamsRef.x = (x - pinSize / 2f).toInt().coerceAtLeast(0)
        pinView.layoutParamsRef.y = (y - pinSize / 2f).toInt().coerceAtLeast(0)

        wm.addView(pinView, pinView.layoutParamsRef)
        activePins.add(pinView)

        if (ScreenCaptureService.state.value == ScreenCaptureService.ServiceState.RUNNING) {
            pinView.setTouchable(false, wm)
        }

        return pinView
    }

    private fun dismissPinConfigDialog() {
        pointConfigDialog.dismiss()
    }

    private fun showPinConfigDialog(pin: TargetPinView) {
        dismissPinConfigDialog()
        val wm = windowManager ?: return
        pointConfigDialog.show(
            pin = pin,
            profileId = currentProfileId,
            windowManager = wm,
            onReload = { loadExistingPointTargets(currentProfileId) }
        )
    }

    private fun addNewManualPoint() {
        if (currentProfileId == -1L) {
            Toast.makeText(this, "Silakan pilih atau buat profil terlebih dahulu.", Toast.LENGTH_SHORT).show()
            return
        }

        serviceScope.launch(Dispatchers.IO) {
            val data = repository.getProfileWithTargetsDirect(currentProfileId)
            val currentCount = data?.targets?.size ?: 0
            val pointCount = data?.targets?.count { it.targetType == "POINT" } ?: 0
            val nextStepNumber = pointCount + 1

            // Place in a convenient visible area (center screen offset)
            val dm = resources.displayMetrics
            val spawnX = dm.widthPixels / 2f
            val spawnY = (dm.heightPixels / 3f) + (pointCount * 80)

            val newTarget = TargetImage(
                profileId = currentProfileId,
                name = "Titik $nextStepNumber",
                filePath = "",
                threshold = 0.8f,
                delayAfterTapMs = 500L,
                maxTaps = 0,
                priority = currentCount,
                targetType = "POINT",
                pointX = spawnX,
                pointY = spawnY
            )

            val insertedId = repository.insertTargetImage(newTarget)
            AppLogger.log("Titik Sentuh $nextStepNumber ditambahkan pada ($spawnX, $spawnY)")

            withContext(Dispatchers.Main) {
                addPinViewToScreen(spawnX, spawnY, nextStepNumber, insertedId)
                Toast.makeText(this@OverlayService, "Titik Sentuh $nextStepNumber dibuat! Geser pin ke tombol yang diinginkan.", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun removeLastManualPoint() {
        if (activePins.isEmpty()) {
            Toast.makeText(this, "Tidak ada titik sentuh manual untuk dihapus.", Toast.LENGTH_SHORT).show()
            return
        }

        val lastPin = activePins.removeAt(activePins.size - 1)
        try { windowManager?.removeView(lastPin) } catch (e: Exception) {}

        serviceScope.launch(Dispatchers.IO) {
            val data = repository.getProfileWithTargetsDirect(currentProfileId)
            val targetToDelete = data?.targets?.find { it.id == lastPin.targetId }
            if (targetToDelete != null) {
                repository.deleteTargetImage(targetToDelete)
                AppLogger.log("Titik Sentuh ${lastPin.stepNumber} telah dihapus.")
            }
            withContext(Dispatchers.Main) {
                Toast.makeText(this@OverlayService, "Titik Sentuh ${lastPin.stepNumber} dihapus.", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun togglePinsVisibility() {
        arePinsVisible = !arePinsVisible
        activePins.forEach { pin ->
            pin.visibility = if (arePinsVisible) View.VISIBLE else View.GONE
        }
        togglePinsButton?.setColorFilter(if (arePinsVisible) Color.parseColor("#00E5FF") else Color.parseColor("#757575"))
        Toast.makeText(this, if (arePinsVisible) "Titik sentuh ditampilkan" else "Titik sentuh disembunyikan", Toast.LENGTH_SHORT).show()
    }

    private fun createFloatingWidget() {
        val context = this
        overlayView = FrameLayout(context)

        // Setup layout params for System Overlay
        val layoutType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        layoutParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            layoutType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 60
            y = 180
        }

        // --- DRAWABLES (Rounded corners programmatically) ---
        val collapsedBg = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(Color.parseColor("#121212")) // Dark Onyx
            setStroke(dpToPx(2), Color.parseColor("#00E5FF")) // Cyan Accent ring
        }

        val expandedBg = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = dpToPx(16).toFloat()
            setColor(Color.parseColor("#161922")) // Dark Slate
            setStroke(dpToPx(2), Color.parseColor("#00E5FF")) // Neon Cyan border
        }

        // ================= COLLAPSED LAYOUT =================
        collapsedLayout = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            background = collapsedBg
            setPadding(dpToPx(8), dpToPx(8), dpToPx(8), dpToPx(8))
            
            // Icon (Target crosshair)
            val icon = ImageView(context).apply {
                setImageResource(android.R.drawable.ic_menu_compass)
                setColorFilter(Color.parseColor("#00E5FF")) // Cyan
                layoutParams = LinearLayout.LayoutParams(dpToPx(40), dpToPx(40))
            }
            addView(icon)
        }

        // ================= EXPANDED CONTROLLER LAYOUT =================
        expandedLayout = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = expandedBg
            visibility = View.GONE
            setPadding(dpToPx(10), dpToPx(8), dpToPx(10), dpToPx(8))

            // Text Info Panel
            val infoLayout = LinearLayout(context).apply {
                orientation = LinearLayout.VERTICAL
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ).apply {
                    rightMargin = dpToPx(8)
                }
            }

            profileNameText = TextView(context).apply {
                text = "Auto Tap"
                setTextColor(Color.WHITE)
                textSize = 12f
                paint.isFakeBoldText = true
            }
            infoLayout.addView(profileNameText)

            statusText = TextView(context).apply {
                text = "Idle"
                setTextColor(Color.parseColor("#AAAAAA"))
                textSize = 10f
            }
            infoLayout.addView(statusText)

            tapCountText = TextView(context).apply {
                text = "Ketukan: 0"
                setTextColor(Color.parseColor("#00E676")) // Vibrant neon green
                textSize = 10f
                paint.isFakeBoldText = true
            }
            infoLayout.addView(tapCountText)

            addView(infoLayout)

            // Button 1: Play/Pause
            playPauseButton = ImageView(context).apply {
                setImageResource(android.R.drawable.ic_media_play)
                setColorFilter(Color.parseColor("#00E676")) // Neon green
                setPadding(dpToPx(6), dpToPx(6), dpToPx(6), dpToPx(6))
                layoutParams = LinearLayout.LayoutParams(dpToPx(36), dpToPx(36)).apply {
                    rightMargin = dpToPx(6)
                }
                isClickable = true
                
                val bg = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(Color.parseColor("#222834"))
                }
                background = bg

                setOnClickListener {
                    toggleTappingState()
                }
            }
            addView(playPauseButton)

            // Button 2: Tambah Titik Manual (+)
            val addPointButton = ImageView(context).apply {
                setImageResource(android.R.drawable.ic_input_add)
                setColorFilter(Color.parseColor("#00E5FF")) // Cyan
                setPadding(dpToPx(6), dpToPx(6), dpToPx(6), dpToPx(6))
                layoutParams = LinearLayout.LayoutParams(dpToPx(36), dpToPx(36)).apply {
                    rightMargin = dpToPx(6)
                }
                isClickable = true
                
                val bg = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(Color.parseColor("#222834"))
                }
                background = bg

                setOnClickListener {
                    addNewManualPoint()
                }
            }
            addView(addPointButton)

            // Button 3: Hapus Titik Terakhir (-)
            val removePointButton = ImageView(context).apply {
                setImageResource(android.R.drawable.ic_delete)
                setColorFilter(Color.parseColor("#FF9800")) // Orange
                setPadding(dpToPx(6), dpToPx(6), dpToPx(6), dpToPx(6))
                layoutParams = LinearLayout.LayoutParams(dpToPx(36), dpToPx(36)).apply {
                    rightMargin = dpToPx(6)
                }
                isClickable = true
                
                val bg = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(Color.parseColor("#222834"))
                }
                background = bg

                setOnClickListener {
                    removeLastManualPoint()
                }
            }
            addView(removePointButton)

            // Button 4: Toggle Pin Visibility (Eye icon)
            togglePinsButton = ImageView(context).apply {
                setImageResource(android.R.drawable.ic_menu_view)
                setColorFilter(Color.parseColor("#00E5FF")) // Cyan
                setPadding(dpToPx(6), dpToPx(6), dpToPx(6), dpToPx(6))
                layoutParams = LinearLayout.LayoutParams(dpToPx(36), dpToPx(36)).apply {
                    rightMargin = dpToPx(6)
                }
                isClickable = true
                
                val bg = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(Color.parseColor("#222834"))
                }
                background = bg

                setOnClickListener {
                    togglePinsVisibility()
                }
            }
            addView(togglePinsButton)

            // Button 5: Stop/Close Overlay
            val stopButton = ImageView(context).apply {
                setImageResource(android.R.drawable.ic_menu_close_clear_cancel)
                setColorFilter(Color.parseColor("#FF1744")) // Vibrant Red
                setPadding(dpToPx(6), dpToPx(6), dpToPx(6), dpToPx(6))
                layoutParams = LinearLayout.LayoutParams(dpToPx(36), dpToPx(36))
                isClickable = true
                
                val bg = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(Color.parseColor("#222834"))
                }
                background = bg

                setOnClickListener {
                    stopAllServices()
                }
            }
            addView(stopButton)
        }

        // Add sublayouts to frame container
        overlayView?.addView(collapsedLayout)
        overlayView?.addView(expandedLayout)

        // Set touch/drag listeners
        setupDragListener()

        // Inflate view into WindowManager
        windowManager?.addView(overlayView, layoutParams)
    }

    private fun toggleTappingState() {
        val currentState = ScreenCaptureService.state.value
        
        if (currentState != ScreenCaptureService.ServiceState.RUNNING && !TapAccessibilityService.isRunning()) {
            Toast.makeText(this, "⚠️ Layanan Aksesibilitas belum aktif! Silakan aktifkan di Pengaturan agar auto-clicker dapat menekan layar.", Toast.LENGTH_LONG).show()
            try {
                val intent = Intent(android.provider.Settings.ACTION_ACCESSIBILITY_SETTINGS).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                startActivity(intent)
            } catch (e: Exception) {
                Log.e(TAG, "Cannot open accessibility settings", e)
            }
            return
        }

        val intent = Intent(this, ScreenCaptureService::class.java).apply {
            if (currentState == ScreenCaptureService.ServiceState.RUNNING) {
                action = ACTION_PAUSE_TAPPING
            } else {
                action = ACTION_START_TAPPING
                putExtra(EXTRA_PROFILE_ID, currentProfileId)
            }
        }
        startService(intent)
    }

    private fun stopAllServices() {
        // Stop screen capturing
        val stopCaptureIntent = Intent(this, ScreenCaptureService::class.java).apply {
            action = ACTION_STOP
        }
        startService(stopCaptureIntent)

        // Stop this overlay service
        stopSelf()
    }

    private fun setPinsTouchable(touchable: Boolean) {
        val wm = windowManager ?: return
        activePins.forEach { pin ->
            pin.setTouchable(touchable, wm)
        }
    }

    private fun observeServiceState() {
        serviceScope.launch {
            ScreenCaptureService.state.collect { state ->
                when (state) {
                    ScreenCaptureService.ServiceState.STOPPED -> {
                        statusText?.text = "Stopped"
                        playPauseButton?.setImageResource(android.R.drawable.ic_media_play)
                        playPauseButton?.setColorFilter(Color.parseColor("#00E676"))
                        setPinsTouchable(true)
                    }
                    ScreenCaptureService.ServiceState.IDLE -> {
                        statusText?.text = "Ready"
                        playPauseButton?.setImageResource(android.R.drawable.ic_media_play)
                        playPauseButton?.setColorFilter(Color.parseColor("#00E676"))
                        setPinsTouchable(true)
                    }
                    ScreenCaptureService.ServiceState.RUNNING -> {
                        statusText?.text = "Running..."
                        playPauseButton?.setImageResource(android.R.drawable.ic_media_pause)
                        playPauseButton?.setColorFilter(Color.parseColor("#FFD700")) // Gold/Yellow pause
                        dismissPinConfigDialog()
                        // When running, make all target pins non-touchable so virtual taps pass directly through to the app/game!
                        setPinsTouchable(false)
                    }
                    ScreenCaptureService.ServiceState.PAUSED -> {
                        statusText?.text = "Paused"
                        playPauseButton?.setImageResource(android.R.drawable.ic_media_play)
                        playPauseButton?.setColorFilter(Color.parseColor("#00E676"))
                        setPinsTouchable(true)
                    }
                }
            }
        }

        serviceScope.launch {
            ScreenCaptureService.totalTapCount.collect { count ->
                tapCountText?.text = "Ketukan: $count"
            }
        }

        serviceScope.launch {
            ScreenCaptureService.matchHighlights.collect { event ->
                highlightView?.showHighlight(event.rect, event.screenX, event.screenY, event.targetName)
            }
        }
    }

    private fun setupDragListener() {
        overlayView?.setOnTouchListener(object : View.OnTouchListener {
            private var initialX = 0
            private var initialY = 0
            private var initialTouchX = 0f
            private var initialTouchY = 0f
            private var isDragging = false

            override fun onTouch(v: View, event: MotionEvent): Boolean {
                val lp = layoutParams ?: return false
                val wm = windowManager ?: return false

                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        initialX = lp.x
                        initialY = lp.y
                        initialTouchX = event.rawX
                        initialTouchY = event.rawY
                        isDragging = false
                        return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = (event.rawX - initialTouchX).toInt()
                        val dy = (event.rawY - initialTouchY).toInt()

                        // Treat as drag if moved more than 8 pixels
                        if (Math.abs(dx) > 8 || Math.abs(dy) > 8) {
                            isDragging = true
                        }

                        if (isDragging) {
                            lp.x = initialX + dx
                            lp.y = initialY + dy
                            wm.updateViewLayout(overlayView, lp)
                        }
                        return true
                    }
                    MotionEvent.ACTION_UP -> {
                        if (!isDragging) {
                            // Toggles Expanded / Collapsed state upon click
                            isExpanded = !isExpanded
                            if (isExpanded) {
                                collapsedLayout?.visibility = View.GONE
                                expandedLayout?.visibility = View.VISIBLE
                            } else {
                                collapsedLayout?.visibility = View.VISIBLE
                                expandedLayout?.visibility = View.GONE
                            }
                        }
                        return true
                    }
                }
                return false
            }
        })
    }

    private fun dpToPx(dp: Int): Int {
        val density = resources.displayMetrics.density
        return Math.round(dp * density)
    }

    override fun onDestroy() {
        pointConfigDialog.dismiss()
        serviceScope.cancel()
        clearAllPins()
        overlayView?.let {
            try { windowManager?.removeView(it) } catch (e: Exception) {}
        }
        highlightView?.let {
            try { windowManager?.removeView(it) } catch (e: Exception) {}
        }
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        private const val TAG = "OverlayService"
        const val EXTRA_PROFILE_NAME = "com.example.extra.PROFILE_NAME"
        const val EXTRA_PROFILE_ID = "com.example.extra.PROFILE_ID"
    }
}
