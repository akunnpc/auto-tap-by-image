package com.example.service

import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import com.example.data.ProfileRepository
import com.example.ui.overlay.TargetPinView
import com.example.util.AppLogger
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Owns the editable target-point overlay dialog. Keeping the form construction
 * outside OverlayService prevents the service from becoming a UI god-class.
 */
class PointConfigDialogController(
    private val context: Context,
    private val repository: ProfileRepository,
    private val scope: CoroutineScope,
    private val onDismiss: () -> Unit
) {

    private var activeView: View? = null

    fun show(
        pin: TargetPinView,
        profileId: Long,
        windowManager: WindowManager,
        onReload: () -> Unit
    ) {
        dismiss()

        scope.launch(Dispatchers.IO) {
            val data = repository.getProfileWithTargetsDirect(profileId)
            val target = data?.targets?.find { it.id == pin.targetId }
            if (target == null) {
                withContext(Dispatchers.Main) {
                    Toast.makeText(context, "Target titik tidak ditemukan.", Toast.LENGTH_SHORT).show()
                }
                return@launch
            }

            withContext(Dispatchers.Main) {
                val density = context.resources.displayMetrics.density

// Main full-screen translucent overlay container
val rootLayout = FrameLayout(context).apply {
    setBackgroundColor(Color.parseColor("#99000000")) // semi-transparent dark backdrop
}

// Inner Dialog Card Container
val dialogCard = LinearLayout(context).apply {
    orientation = LinearLayout.VERTICAL
    setPadding(dpToPx(16), dpToPx(16), dpToPx(16), dpToPx(16))
    val bg = GradientDrawable().apply {
        cornerRadius = dpToPx(16).toFloat()
        setColor(Color.parseColor("#161922")) // Dark Slate background
        setStroke(dpToPx(2), Color.parseColor("#00E5FF")) // Cyber Cyan border
    }
    background = bg

    val lp = FrameLayout.LayoutParams(
        (320 * density).toInt(),
        FrameLayout.LayoutParams.WRAP_CONTENT
    ).apply {
        gravity = Gravity.CENTER
    }
    layoutParams = lp
}

// Header Row
val headerRow = LinearLayout(context).apply {
    orientation = LinearLayout.HORIZONTAL
    gravity = Gravity.CENTER_VERTICAL
    layoutParams = LinearLayout.LayoutParams(
        LinearLayout.LayoutParams.MATCH_PARENT,
        LinearLayout.LayoutParams.WRAP_CONTENT
    ).apply { bottomMargin = dpToPx(12) }
}

val titleText = TextView(context).apply {
    text = "⚙️ Pengaturan Titik #${pin.stepNumber}"
    setTextColor(Color.parseColor("#00E5FF"))
    textSize = 16f
    paint.isFakeBoldText = true
    layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
}
val closeBtn = ImageView(context).apply {
    setImageResource(android.R.drawable.ic_menu_close_clear_cancel)
    setColorFilter(Color.parseColor("#8899A6"))
    setPadding(dpToPx(4), dpToPx(4), dpToPx(4), dpToPx(4))
    setOnClickListener { dismiss() }
}
headerRow.addView(titleText)
headerRow.addView(closeBtn)
dialogCard.addView(headerRow)

// Scrollview for form fields
val scrollView = ScrollView(context).apply {
    layoutParams = LinearLayout.LayoutParams(
        LinearLayout.LayoutParams.MATCH_PARENT,
        LinearLayout.LayoutParams.WRAP_CONTENT
    )
}
val formLayout = LinearLayout(context).apply {
    orientation = LinearLayout.VERTICAL
}

// 1. Label & Name Field
val nameLabel = TextView(context).apply {
    text = "Nama Titik / Tombol:"
    setTextColor(Color.parseColor("#8899A6"))
    textSize = 12f
}
val nameInput = EditText(context).apply {
    setText(target.name)
    setTextColor(Color.WHITE)
    setHintTextColor(Color.parseColor("#556070"))
    hint = "Misal: Tombol Pasukan A"
    textSize = 14f
    val inputBg = GradientDrawable().apply {
        cornerRadius = dpToPx(8).toFloat()
        setColor(Color.parseColor("#222834"))
        setStroke(dpToPx(1), Color.parseColor("#333D4F"))
    }
    background = inputBg
    setPadding(dpToPx(10), dpToPx(8), dpToPx(10), dpToPx(8))
    layoutParams = LinearLayout.LayoutParams(
        LinearLayout.LayoutParams.MATCH_PARENT,
        LinearLayout.LayoutParams.WRAP_CONTENT
    ).apply {
        topMargin = dpToPx(4)
        bottomMargin = dpToPx(12)
    }
}
formLayout.addView(nameLabel)
formLayout.addView(nameInput)

// 2. Action Type (Tap vs Hold)
val actionLabel = TextView(context).apply {
    text = "Tipe Tindakan:"
    setTextColor(Color.parseColor("#8899A6"))
    textSize = 12f
}
val actionRadioGroup = RadioGroup(context).apply {
    orientation = RadioGroup.HORIZONTAL
    layoutParams = LinearLayout.LayoutParams(
        LinearLayout.LayoutParams.MATCH_PARENT,
        LinearLayout.LayoutParams.WRAP_CONTENT
    ).apply {
        topMargin = dpToPx(4)
        bottomMargin = dpToPx(8)
    }
}
val tapRadio = RadioButton(context).apply {
    text = "Ketuk (Tap)"
    setTextColor(Color.WHITE)
    textSize = 13f
    id = View.generateViewId()
}
val holdRadio = RadioButton(context).apply {
    text = "Tahan (Hold)"
    setTextColor(Color.WHITE)
    textSize = 13f
    id = View.generateViewId()
}
actionRadioGroup.addView(tapRadio)
actionRadioGroup.addView(holdRadio)
if (target.actionType == "LONG_PRESS") {
    holdRadio.isChecked = true
} else {
    tapRadio.isChecked = true
}
formLayout.addView(actionLabel)
formLayout.addView(actionRadioGroup)

// Hold Duration Input Container
val holdContainer = LinearLayout(context).apply {
    orientation = LinearLayout.VERTICAL
    visibility = if (target.actionType == "LONG_PRESS") View.VISIBLE else View.GONE
    layoutParams = LinearLayout.LayoutParams(
        LinearLayout.LayoutParams.MATCH_PARENT,
        LinearLayout.LayoutParams.WRAP_CONTENT
    ).apply { bottomMargin = dpToPx(10) }
}
val holdLabel = TextView(context).apply {
    text = "Durasi Tahan (ms):"
    setTextColor(Color.parseColor("#8899A6"))
    textSize = 12f
}
val holdInput = EditText(context).apply {
    inputType = InputType.TYPE_CLASS_NUMBER
    setText(target.holdDurationMs.toString())
    setTextColor(Color.WHITE)
    textSize = 14f
    val inputBg = GradientDrawable().apply {
        cornerRadius = dpToPx(8).toFloat()
        setColor(Color.parseColor("#222834"))
        setStroke(dpToPx(1), Color.parseColor("#333D4F"))
    }
    background = inputBg
    setPadding(dpToPx(10), dpToPx(8), dpToPx(10), dpToPx(8))
    layoutParams = LinearLayout.LayoutParams(
        LinearLayout.LayoutParams.MATCH_PARENT,
        LinearLayout.LayoutParams.WRAP_CONTENT
    ).apply { topMargin = dpToPx(4) }
}
holdContainer.addView(holdLabel)
holdContainer.addView(holdInput)
formLayout.addView(holdContainer)

actionRadioGroup.setOnCheckedChangeListener { _, checkedId ->
    holdContainer.visibility = if (checkedId == holdRadio.id) View.VISIBLE else View.GONE
}

// 3. Delay / Jeda Waktu Setelah Sentuh (ms, Detik, Menit)
val delaySectionTitle = TextView(context).apply {
    text = "⏱️ Delay / Interval Setelah Sentuh:"
    setTextColor(Color.parseColor("#00E5FF"))
    textSize = 13f
    paint.isFakeBoldText = true
    layoutParams = LinearLayout.LayoutParams(
        LinearLayout.LayoutParams.WRAP_CONTENT,
        LinearLayout.LayoutParams.WRAP_CONTENT
    ).apply { topMargin = dpToPx(4) }
}
formLayout.addView(delaySectionTitle)

// Determine initial unit and value from target.delayAfterTapMs
val rawDelay = target.delayAfterTapMs
var initialUnit = "ms"
var initialValueStr = rawDelay.toString()
if (rawDelay >= 60000L && rawDelay % 60000L == 0L) {
    initialUnit = "mnt"
    initialValueStr = (rawDelay / 60000L).toString()
} else if (rawDelay >= 1000L && rawDelay % 1000L == 0L) {
    initialUnit = "dtk"
    initialValueStr = (rawDelay / 1000L).toString()
}

val delayInputRow = LinearLayout(context).apply {
    orientation = LinearLayout.HORIZONTAL
    gravity = Gravity.CENTER_VERTICAL
    layoutParams = LinearLayout.LayoutParams(
        LinearLayout.LayoutParams.MATCH_PARENT,
        LinearLayout.LayoutParams.WRAP_CONTENT
    ).apply { topMargin = dpToPx(4) }
}

val delayInput = EditText(context).apply {
    inputType = InputType.TYPE_CLASS_NUMBER
    setText(initialValueStr)
    setTextColor(Color.WHITE)
    textSize = 14f
    val inputBg = GradientDrawable().apply {
        cornerRadius = dpToPx(8).toFloat()
        setColor(Color.parseColor("#222834"))
        setStroke(dpToPx(1), Color.parseColor("#333D4F"))
    }
    background = inputBg
    setPadding(dpToPx(10), dpToPx(8), dpToPx(10), dpToPx(8))
    layoutParams = LinearLayout.LayoutParams(
        dpToPx(85),
        LinearLayout.LayoutParams.WRAP_CONTENT
    )
}

val unitRadioGroup = RadioGroup(context).apply {
    orientation = RadioGroup.HORIZONTAL
    layoutParams = LinearLayout.LayoutParams(
        LinearLayout.LayoutParams.MATCH_PARENT,
        LinearLayout.LayoutParams.WRAP_CONTENT
    ).apply { leftMargin = dpToPx(4) }
}

val radioMs = RadioButton(context).apply {
    text = "ms"
    setTextColor(Color.WHITE)
    textSize = 11f
    id = View.generateViewId()
}
val radioSec = RadioButton(context).apply {
    text = "Detik"
    setTextColor(Color.WHITE)
    textSize = 11f
    id = View.generateViewId()
}
val radioMin = RadioButton(context).apply {
    text = "Menit"
    setTextColor(Color.WHITE)
    textSize = 11f
    id = View.generateViewId()
}
unitRadioGroup.addView(radioMs)
unitRadioGroup.addView(radioSec)
unitRadioGroup.addView(radioMin)

when (initialUnit) {
    "mnt" -> radioMin.isChecked = true
    "dtk" -> radioSec.isChecked = true
    else -> radioMs.isChecked = true
}

delayInputRow.addView(delayInput)
delayInputRow.addView(unitRadioGroup)
formLayout.addView(delayInputRow)

// Subtitle preview
val delayPreviewText = TextView(context).apply {
    text = "Jeda eksekusi: $rawDelay ms (${rawDelay / 1000f} detik)"
    setTextColor(Color.parseColor("#00E676"))
    textSize = 11f
    layoutParams = LinearLayout.LayoutParams(
        LinearLayout.LayoutParams.WRAP_CONTENT,
        LinearLayout.LayoutParams.WRAP_CONTENT
    ).apply {
        topMargin = dpToPx(4)
        bottomMargin = dpToPx(10)
    }
}
formLayout.addView(delayPreviewText)

val updatePreview = {
    val num = delayInput.text.toString().toDoubleOrNull() ?: 0.0
    val multiplier = when (unitRadioGroup.checkedRadioButtonId) {
        radioMin.id -> 60000L
        radioSec.id -> 1000L
        else -> 1L
    }
    val finalMs = (num * multiplier).toLong()
    delayPreviewText.text = "Jeda eksekusi: $finalMs ms (${finalMs / 1000f} detik)"
}

delayInput.addTextChangedListener(object : android.text.TextWatcher {
    override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
    override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { updatePreview() }
    override fun afterTextChanged(s: android.text.Editable?) {}
})
unitRadioGroup.setOnCheckedChangeListener { _, _ -> updatePreview() }

// 4. Coordinates Info
val coordText = TextView(context).apply {
    text = "📍 Posisi Titik: (${target.pointX.toInt()} px, ${target.pointY.toInt()} px)"
    setTextColor(Color.parseColor("#8899A6"))
    textSize = 11f
    layoutParams = LinearLayout.LayoutParams(
        LinearLayout.LayoutParams.WRAP_CONTENT,
        LinearLayout.LayoutParams.WRAP_CONTENT
    ).apply { bottomMargin = dpToPx(14) }
}
formLayout.addView(coordText)

// 5. Action Buttons (Hapus, Batal, Simpan)
val buttonsRow = LinearLayout(context).apply {
    orientation = LinearLayout.HORIZONTAL
    layoutParams = LinearLayout.LayoutParams(
        LinearLayout.LayoutParams.MATCH_PARENT,
        LinearLayout.LayoutParams.WRAP_CONTENT
    )
}

// Delete Button
val deleteBtn = Button(context).apply {
    text = "Hapus"
    setTextColor(Color.WHITE)
    textSize = 12f
    paint.isFakeBoldText = true
    val btnBg = GradientDrawable().apply {
        cornerRadius = dpToPx(8).toFloat()
        setColor(Color.parseColor("#D32F2F"))
    }
    background = btnBg
    layoutParams = LinearLayout.LayoutParams(0, dpToPx(38), 1f).apply { rightMargin = dpToPx(6) }
    setOnClickListener {
        scope.launch(Dispatchers.IO) {
            repository.deleteTargetImage(target)
            AppLogger.log("Titik Sentuh #${pin.stepNumber} dihapus.")
            withContext(Dispatchers.Main) {
                dismiss()
                onReload()
                Toast.makeText(context, "Titik #${pin.stepNumber} telah dihapus", Toast.LENGTH_SHORT).show()
            }
        }
    }
}

// Cancel Button
val cancelBtn = Button(context).apply {
    text = "Batal"
    setTextColor(Color.WHITE)
    textSize = 12f
    val btnBg = GradientDrawable().apply {
        cornerRadius = dpToPx(8).toFloat()
        setColor(Color.parseColor("#333742"))
    }
    background = btnBg
    layoutParams = LinearLayout.LayoutParams(0, dpToPx(38), 1f).apply { rightMargin = dpToPx(6) }
    setOnClickListener { dismiss() }
}

// Save Button
val saveBtn = Button(context).apply {
    text = "Simpan"
    setTextColor(Color.parseColor("#121212"))
    textSize = 12f
    paint.isFakeBoldText = true
    val btnBg = GradientDrawable().apply {
        cornerRadius = dpToPx(8).toFloat()
        setColor(Color.parseColor("#00E5FF")) // Cyber Cyan
    }
    background = btnBg
    layoutParams = LinearLayout.LayoutParams(0, dpToPx(38), 1.2f)
    setOnClickListener {
        val inputNum = delayInput.text.toString().toDoubleOrNull() ?: 500.0
        val multiplier = when (unitRadioGroup.checkedRadioButtonId) {
            radioMin.id -> 60000L
            radioSec.id -> 1000L
            else -> 1L
        }
        val finalDelayMs = (inputNum * multiplier).toLong().coerceAtLeast(10L)

        val actType = if (holdRadio.isChecked) "LONG_PRESS" else "TAP"
        val holdMs = holdInput.text.toString().toLongOrNull() ?: 1000L
        val newName = if (nameInput.text.isNotBlank()) nameInput.text.toString().trim() else target.name

        scope.launch(Dispatchers.IO) {
            val updated = target.copy(
                name = newName,
                actionType = actType,
                holdDurationMs = holdMs,
                delayAfterTapMs = finalDelayMs
            )
            repository.updateTargetImage(updated)
            AppLogger.log("Pengaturan Titik #${pin.stepNumber} disimpan: Delay $finalDelayMs ms ($actType)")
            withContext(Dispatchers.Main) {
                dismiss()
                Toast.makeText(context, "Pengaturan Titik #${pin.stepNumber} disimpan! (Delay: $finalDelayMs ms)", Toast.LENGTH_SHORT).show()
            }
        }
    }
}

buttonsRow.addView(deleteBtn)
buttonsRow.addView(cancelBtn)
buttonsRow.addView(saveBtn)
formLayout.addView(buttonsRow)

scrollView.addView(formLayout)
dialogCard.addView(scrollView)
rootLayout.addView(dialogCard)

// Root backdrop click dismisses dialog
rootLayout.setOnClickListener { dismiss() }
dialogCard.setOnClickListener { /* prevent dismiss when clicking dialog card */ }

// WindowManager LayoutParams for interactive dialog window
val layoutType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
    WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
} else {
    @Suppress("DEPRECATION")
    WindowManager.LayoutParams.TYPE_PHONE
}

val dialogParams = WindowManager.LayoutParams(
    WindowManager.LayoutParams.MATCH_PARENT,
    WindowManager.LayoutParams.MATCH_PARENT,
    layoutType,
    WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
    PixelFormat.TRANSLUCENT
).apply {
    gravity = Gravity.CENTER
    softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
}

wm.addView(rootLayout, dialogParams)
activeView = rootLayout
            }
        }
    }

    fun dismiss() {
        activeView?.let {
            try {
                (context.getSystemService(Context.WINDOW_SERVICE) as? WindowManager)?.removeView(it)
            } catch (_: Exception) {
            }
            activeView = null
        }
        onDismiss()
    }

    private fun dpToPx(dp: Int): Int =
        Math.round(dp * context.resources.displayMetrics.density)
}
