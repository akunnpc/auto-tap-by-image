package com.example.service

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.Build
import android.util.Log
import android.view.accessibility.AccessibilityEvent

class TapAccessibilityService : AccessibilityService() {

    override fun onServiceConnected() {
        super.onServiceConnected()
        Log.d(TAG, "TapAccessibilityService connected successfully")
        instance = this
    }

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        Log.d(TAG, "TapAccessibilityService unbound")
        instance = null
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        Log.d(TAG, "TapAccessibilityService destroyed")
        instance = null
        super.onDestroy()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // No events to process - we only use this for simulating gestural clicks
    }

    override fun onInterrupt() {
        Log.w(TAG, "Accessibility Service Interrupted")
    }

    /**
     * Performs a simulated gesture click (tap) at the specified screen coordinates.
     */
    fun tapAt(x: Float, y: Float, callback: ((Boolean) -> Unit)? = null) {
        val clickPath = Path().apply {
            moveTo(x, y)
        }
        
        // Simulating a fast tap: duration 50ms, start at 0ms
        val stroke = GestureDescription.StrokeDescription(clickPath, 0L, 50L)
        val gesture = GestureDescription.Builder().apply {
            addStroke(stroke)
        }.build()

        val success = dispatchGesture(gesture, object : GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) {
                super.onCompleted(gestureDescription)
                Log.d(TAG, "Gesture click successfully completed at ($x, $y)")
                callback?.invoke(true)
            }

            override fun onCancelled(gestureDescription: GestureDescription?) {
                super.onCancelled(gestureDescription)
                Log.e(TAG, "Gesture click cancelled at ($x, $y)")
                callback?.invoke(false)
            }
        }, null)

        if (!success) {
            Log.e(TAG, "Failed to dispatch gesture click at ($x, $y)")
            callback?.invoke(false)
        }
    }

    /**
     * Performs a simulated gesture press and hold at the specified screen coordinates.
     */
    fun longPressAt(x: Float, y: Float, durationMs: Long, callback: ((Boolean) -> Unit)? = null) {
        val clickPath = Path().apply {
            moveTo(x, y)
        }
        
        val stroke = GestureDescription.StrokeDescription(clickPath, 0L, durationMs)
        val gesture = GestureDescription.Builder().apply {
            addStroke(stroke)
        }.build()

        val success = dispatchGesture(gesture, object : GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) {
                super.onCompleted(gestureDescription)
                Log.d(TAG, "Gesture long-press successfully completed at ($x, $y) for ${durationMs}ms")
                callback?.invoke(true)
            }

            override fun onCancelled(gestureDescription: GestureDescription?) {
                super.onCancelled(gestureDescription)
                Log.e(TAG, "Gesture long-press cancelled at ($x, $y)")
                callback?.invoke(false)
            }
        }, null)

        if (!success) {
            Log.e(TAG, "Failed to dispatch gesture long-press at ($x, $y)")
            callback?.invoke(false)
        }
    }

    companion object {
        private const val TAG = "TapAccessibility"
        
        @Volatile
        private var instance: TapAccessibilityService? = null

        /**
         * Checks if the Accessibility Service is currently enabled and connected.
         */
        fun isRunning(): Boolean = instance != null

        /**
         * Utility function to trigger a tap at (x, y) if the service is running.
         */
        fun performTap(x: Float, y: Float, callback: ((Boolean) -> Unit)? = null): Boolean {
            val service = instance
            if (service != null) {
                service.tapAt(x, y, callback)
                return true
            }
            Log.e(TAG, "Cannot tap: TapAccessibilityService is not running.")
            callback?.invoke(false)
            return false
        }

        /**
         * Utility function to trigger a long-press at (x, y) for a duration if the service is running.
         */
        fun performLongPress(x: Float, y: Float, durationMs: Long, callback: ((Boolean) -> Unit)? = null): Boolean {
            val service = instance
            if (service != null) {
                service.longPressAt(x, y, durationMs, callback)
                return true
            }
            Log.e(TAG, "Cannot long-press: TapAccessibilityService is not running.")
            callback?.invoke(false)
            return false
        }
    }
}
