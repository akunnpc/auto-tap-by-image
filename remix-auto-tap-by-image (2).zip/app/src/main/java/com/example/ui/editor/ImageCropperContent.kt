package com.example.ui.editor

import android.graphics.Bitmap
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.CenterFocusStrong
import androidx.compose.material.icons.filled.Fullscreen
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*
import com.example.util.BitmapHelper
import kotlin.math.roundToInt

@Composable
fun ImageCropperContent(
    bitmap: Bitmap,
    onCropConfirmed: (Bitmap) -> Unit,
    onCropFailed: () -> Unit
) {
    // Normalized crop box boundaries (0.0 to 1.0 relative to the image)
    var normLeft by remember { mutableFloatStateOf(0.15f) }
    var normTop by remember { mutableFloatStateOf(0.15f) }
    var normRight by remember { mutableFloatStateOf(0.85f) }
    var normBottom by remember { mutableFloatStateOf(0.85f) }

    val density = LocalDensity.current

    // Corner handle touch targets (48dp for comfortable finger dragging)
    val handleTouchSize = 48.dp
    val handleTouchSizePx = with(density) { handleTouchSize.toPx() }
    val handleVisualSize = 20.dp

    val bitmapWidth = bitmap.width.toFloat()
    val bitmapHeight = bitmap.height.toFloat()
    val imageAspect = if (bitmapHeight > 0f) bitmapWidth / bitmapHeight else 1f

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF14171F))
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Header Text matching the user's screenshot
        Text(
            text = "Geser & Sesuaikan Kotak ke Bagian Target",
            fontWeight = FontWeight.Bold,
            color = Color.White,
            fontSize = 15.sp,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(top = 4.dp, bottom = 4.dp)
        )

        // Main Cropping Area Container
        BoxWithConstraints(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .clip(RoundedCornerShape(14.dp))
                .background(Color(0xFF0D0F14))
                .border(1.dp, BorderSlate.copy(alpha = 0.5f), RoundedCornerShape(14.dp)),
            contentAlignment = Alignment.Center
        ) {
            val containerWidthPx = constraints.maxWidth.toFloat()
            val containerHeightPx = constraints.maxHeight.toFloat()
            val containerAspect = if (containerHeightPx > 0f) containerWidthPx / containerHeightPx else 1f

            // Calculate actual rendered image dimensions and offsets (equivalent to ContentScale.Fit)
            val renderW: Float
            val renderH: Float
            val offsetX: Float
            val offsetY: Float

            if (imageAspect > containerAspect) {
                renderW = containerWidthPx
                renderH = if (imageAspect > 0f) containerWidthPx / imageAspect else containerHeightPx
                offsetX = 0f
                offsetY = (containerHeightPx - renderH) / 2f
            } else {
                renderH = containerHeightPx
                renderW = containerHeightPx * imageAspect
                offsetX = (containerWidthPx - renderW) / 2f
                offsetY = 0f
            }

            // Minimum crop box size in normalized units (at least 36dp or 5% of dimension)
            val minNormW = if (renderW > 0f) (with(density) { 36.dp.toPx() } / renderW).coerceIn(0.02f, 0.4f) else 0.05f
            val minNormH = if (renderH > 0f) (with(density) { 36.dp.toPx() } / renderH).coerceIn(0.02f, 0.4f) else 0.05f

            // Screen pixel coordinates of the crop bounding box
            val cropLeftPx = offsetX + normLeft * renderW
            val cropTopPx = offsetY + normTop * renderH
            val cropRightPx = offsetX + normRight * renderW
            val cropBottomPx = offsetY + normBottom * renderH
            val cropWidthPx = (cropRightPx - cropLeftPx).coerceAtLeast(1f)
            val cropHeightPx = (cropBottomPx - cropTopPx).coerceAtLeast(1f)

            // 1. Rendered Image
            if (renderW > 0f && renderH > 0f) {
                Image(
                    bitmap = bitmap.asImageBitmap(),
                    contentDescription = null,
                    modifier = Modifier
                        .offset { IntOffset(offsetX.roundToInt(), offsetY.roundToInt()) }
                        .size(with(density) { renderW.toDp() }, with(density) { renderH.toDp() }),
                    contentScale = ContentScale.FillBounds
                )

                // 2. Darkened Mask & Box Lines
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val overlayColor = Color.Black.copy(alpha = 0.65f)

                    // Draw 4 darkened rects surrounding the crop box within the image bounds
                    // Top strip
                    if (cropTopPx > offsetY) {
                        drawRect(
                            color = overlayColor,
                            topLeft = Offset(offsetX, offsetY),
                            size = Size(renderW, cropTopPx - offsetY)
                        )
                    }
                    // Bottom strip
                    if (cropBottomPx < offsetY + renderH) {
                        drawRect(
                            color = overlayColor,
                            topLeft = Offset(offsetX, cropBottomPx),
                            size = Size(renderW, (offsetY + renderH) - cropBottomPx)
                        )
                    }
                    // Left strip
                    if (cropLeftPx > offsetX) {
                        drawRect(
                            color = overlayColor,
                            topLeft = Offset(offsetX, cropTopPx),
                            size = Size(cropLeftPx - offsetX, cropHeightPx)
                        )
                    }
                    // Right strip
                    if (cropRightPx < offsetX + renderW) {
                        drawRect(
                            color = overlayColor,
                            topLeft = Offset(cropRightPx, cropTopPx),
                            size = Size((offsetX + renderW) - cropRightPx, cropHeightPx)
                        )
                    }

                    // Rule-of-thirds grid inside crop box
                    val strokeGrid = Stroke(width = 1.dp.toPx())
                    val gridColor = CyberCyan.copy(alpha = 0.25f)
                    val oneThirdW = cropWidthPx / 3f
                    val oneThirdH = cropHeightPx / 3f

                    drawLine(
                        color = gridColor,
                        start = Offset(cropLeftPx + oneThirdW, cropTopPx),
                        end = Offset(cropLeftPx + oneThirdW, cropBottomPx),
                        strokeWidth = strokeGrid.width
                    )
                    drawLine(
                        color = gridColor,
                        start = Offset(cropLeftPx + oneThirdW * 2f, cropTopPx),
                        end = Offset(cropLeftPx + oneThirdW * 2f, cropBottomPx),
                        strokeWidth = strokeGrid.width
                    )
                    drawLine(
                        color = gridColor,
                        start = Offset(cropLeftPx, cropTopPx + oneThirdH),
                        end = Offset(cropRightPx, cropTopPx + oneThirdH),
                        strokeWidth = strokeGrid.width
                    )
                    drawLine(
                        color = gridColor,
                        start = Offset(cropLeftPx, cropTopPx + oneThirdH * 2f),
                        end = Offset(cropRightPx, cropTopPx + oneThirdH * 2f),
                        strokeWidth = strokeGrid.width
                    )

                    // Bounding Box Cyan Border
                    drawRect(
                        color = CyberCyan,
                        topLeft = Offset(cropLeftPx, cropTopPx),
                        size = Size(cropWidthPx, cropHeightPx),
                        style = Stroke(width = 2.5.dp.toPx())
                    )
                }

                // 3. Draggable Interior Box (moves the entire crop box)
                Box(
                    modifier = Modifier
                        .offset { IntOffset(cropLeftPx.roundToInt(), cropTopPx.roundToInt()) }
                        .size(with(density) { cropWidthPx.toDp() }, with(density) { cropHeightPx.toDp() })
                        .pointerInput(renderW, renderH) {
                            detectDragGestures { change, dragAmount ->
                                change.consume()
                                if (renderW <= 0f || renderH <= 0f) return@detectDragGestures

                                val currentW = normRight - normLeft
                                val currentH = normBottom - normTop
                                val deltaX = dragAmount.x / renderW
                                val deltaY = dragAmount.y / renderH

                                var newLeft = normLeft + deltaX
                                var newTop = normTop + deltaY

                                if (newLeft < 0f) newLeft = 0f
                                if (newLeft + currentW > 1f) newLeft = 1f - currentW

                                if (newTop < 0f) newTop = 0f
                                if (newTop + currentH > 1f) newTop = 1f - currentH

                                normLeft = newLeft
                                normRight = newLeft + currentW
                                normTop = newTop
                                normBottom = newTop + currentH
                            }
                        }
                )

                // 4. Draggable Corner Handles (4 pojok bebas)
                // Corner 1: TOP-LEFT
                CornerHandle(
                    centerX = cropLeftPx,
                    centerY = cropTopPx,
                    touchSizePx = handleTouchSizePx,
                    visualSize = handleVisualSize,
                    onDrag = { dx, dy ->
                        if (renderW > 0f && renderH > 0f) {
                            normLeft = (normLeft + dx / renderW).coerceIn(0f, normRight - minNormW)
                            normTop = (normTop + dy / renderH).coerceIn(0f, normBottom - minNormH)
                        }
                    }
                )

                // Corner 2: TOP-RIGHT
                CornerHandle(
                    centerX = cropRightPx,
                    centerY = cropTopPx,
                    touchSizePx = handleTouchSizePx,
                    visualSize = handleVisualSize,
                    onDrag = { dx, dy ->
                        if (renderW > 0f && renderH > 0f) {
                            normRight = (normRight + dx / renderW).coerceIn(normLeft + minNormW, 1f)
                            normTop = (normTop + dy / renderH).coerceIn(0f, normBottom - minNormH)
                        }
                    }
                )

                // Corner 3: BOTTOM-LEFT
                CornerHandle(
                    centerX = cropLeftPx,
                    centerY = cropBottomPx,
                    touchSizePx = handleTouchSizePx,
                    visualSize = handleVisualSize,
                    onDrag = { dx, dy ->
                        if (renderW > 0f && renderH > 0f) {
                            normLeft = (normLeft + dx / renderW).coerceIn(0f, normRight - minNormW)
                            normBottom = (normBottom + dy / renderH).coerceIn(normTop + minNormH, 1f)
                        }
                    }
                )

                // Corner 4: BOTTOM-RIGHT
                CornerHandle(
                    centerX = cropRightPx,
                    centerY = cropBottomPx,
                    touchSizePx = handleTouchSizePx,
                    visualSize = handleVisualSize,
                    onDrag = { dx, dy ->
                        if (renderW > 0f && renderH > 0f) {
                            normRight = (normRight + dx / renderW).coerceIn(normLeft + minNormW, 1f)
                            normBottom = (normBottom + dy / renderH).coerceIn(normTop + minNormH, 1f)
                        }
                    }
                )
            }
        }

        // Quick Controls & Dimension Info Row
        val actualCropW = ((normRight - normLeft) * bitmap.width).roundToInt().coerceAtLeast(1)
        val actualCropH = ((normBottom - normTop) * bitmap.height).roundToInt().coerceAtLeast(1)

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Surface(
                color = SlateCardBg.copy(alpha = 0.8f),
                shape = RoundedCornerShape(8.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, BorderSlate.copy(alpha = 0.6f))
            ) {
                Text(
                    text = "Ukuran: $actualCropW × $actualCropH px",
                    color = CyberCyan,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Medium,
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                )
            }

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(
                    onClick = {
                        normLeft = 0.15f
                        normTop = 0.15f
                        normRight = 0.85f
                        normBottom = 0.85f
                    },
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White),
                    border = androidx.compose.foundation.BorderStroke(1.dp, BorderSlate)
                ) {
                    Icon(Icons.Default.CenterFocusStrong, contentDescription = null, modifier = Modifier.size(14.dp), tint = CyberCyan)
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Pusatkan", fontSize = 11.sp)
                }

                OutlinedButton(
                    onClick = {
                        normLeft = 0f
                        normTop = 0f
                        normRight = 1f
                        normBottom = 1f
                    },
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White),
                    border = androidx.compose.foundation.BorderStroke(1.dp, BorderSlate)
                ) {
                    Icon(Icons.Default.Fullscreen, contentDescription = null, modifier = Modifier.size(14.dp), tint = CyberCyan)
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Penuh", fontSize = 11.sp)
                }
            }
        }

        // Primary Action Button matching the user's screenshot ("LANJUT")
        Button(
            onClick = {
                val cropped = BitmapHelper.cropBitmap(bitmap, normLeft, normRight, normTop, normBottom)
                if (cropped != null) {
                    onCropConfirmed(cropped)
                } else {
                    onCropFailed()
                }
            },
            colors = ButtonDefaults.buttonColors(
                containerColor = Color(0xFF1E232A),
                contentColor = Color.White
            ),
            border = androidx.compose.foundation.BorderStroke(1.dp, CyberCyan.copy(alpha = 0.7f)),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier
                .fillMaxWidth()
                .height(52.dp)
        ) {
            Text(
                text = "LANJUT",
                fontWeight = FontWeight.Bold,
                fontSize = 15.sp,
                letterSpacing = 1.sp,
                color = Color.White
            )
            Spacer(modifier = Modifier.width(8.dp))
            Icon(
                Icons.Default.ArrowForward,
                contentDescription = null,
                modifier = Modifier.size(18.dp),
                tint = CyberCyan
            )
        }
    }
}

/**
 * Interactive Corner Handle that supports freeform resizing from 4 corners.
 * Uses a comfortable 48dp touch target with a crisp circular cyan handle in the center.
 */
@Composable
private fun CornerHandle(
    centerX: Float,
    centerY: Float,
    touchSizePx: Float,
    visualSize: androidx.compose.ui.unit.Dp,
    onDrag: (Float, Float) -> Unit
) {
    val density = LocalDensity.current
    val touchSizeDp = with(density) { touchSizePx.toDp() }
    val offsetX = centerX - touchSizePx / 2f
    val offsetY = centerY - touchSizePx / 2f

    Box(
        modifier = Modifier
            .offset { IntOffset(offsetX.roundToInt(), offsetY.roundToInt()) }
            .size(touchSizeDp)
            .pointerInput(Unit) {
                detectDragGestures { change, dragAmount ->
                    change.consume()
                    onDrag(dragAmount.x, dragAmount.y)
                }
            },
        contentAlignment = Alignment.Center
    ) {
        // Visual circular dot matching the user's screenshot
        Box(
            modifier = Modifier
                .size(visualSize)
                .shadow(elevation = 6.dp, shape = CircleShape)
                .background(CyberCyan, CircleShape)
                .border(2.dp, Color.White.copy(alpha = 0.9f), CircleShape)
        )
    }
}
