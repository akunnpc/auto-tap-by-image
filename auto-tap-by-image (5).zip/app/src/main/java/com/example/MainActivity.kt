package com.example

import android.Manifest
import android.accessibilityservice.AccessibilityService
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import java.io.File
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.delay
import com.example.data.*
import com.example.service.OverlayService
import com.example.service.ScreenCaptureService
import com.example.service.TapAccessibilityService
import com.example.ui.DiagnosticModeDialog
import com.example.ui.theme.MyApplicationTheme
import com.example.util.AppLogger
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    private lateinit var repository: ProfileRepository
    private var selectedProfileToStart: Profile? = null

    // Screen projection request launcher
    private val screenCaptureLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == RESULT_OK && result.data != null) {
            val profile = selectedProfileToStart
            if (profile == null) {
                Toast.makeText(this, "Silakan pilih profil terlebih dahulu.", Toast.LENGTH_SHORT).show()
                return@registerForActivityResult
            }

            val hasApp = profile.packageName.isNotEmpty()
            val launchIntent = if (hasApp) {
                packageManager.getLaunchIntentForPackage(profile.packageName)
            } else null

            if (hasApp && launchIntent == null) {
                Toast.makeText(this, "Aplikasi target tidak ditemukan, mungkin sudah dihapus", Toast.LENGTH_LONG).show()
                return@registerForActivityResult
            }

            lifecycleScope.launch {
                if (hasApp && launchIntent != null) {
                    try {
                        startActivity(launchIntent)
                        AppLogger.log("Membuka aplikasi target: '${profile.appName}'...")
                        delay(2500L) // Jeda 2.5 detik agar aplikasi target selesai loading
                    } catch (e: Exception) {
                        AppLogger.log("Gagal membuka aplikasi target: ${e.message}")
                    }
                }

                // Start foreground capture service
                val captureIntent = Intent(this@MainActivity, ScreenCaptureService::class.java).apply {
                    action = ScreenCaptureService.ACTION_START_PROJECTION
                    putExtra(ScreenCaptureService.EXTRA_RESULT_CODE, result.resultCode)
                    putExtra(ScreenCaptureService.EXTRA_RESULT_DATA, result.data)
                }
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    startForegroundService(captureIntent)
                } else {
                    startService(captureIntent)
                }

                // Start floating overlay controls
                val overlayIntent = Intent(this@MainActivity, OverlayService::class.java).apply {
                    putExtra(OverlayService.EXTRA_PROFILE_NAME, profile.name)
                    putExtra(OverlayService.EXTRA_PROFILE_ID, profile.id)
                }
                startService(overlayIntent)

                // Trigger tapping matching loop inside screen capture service
                val tapIntent = Intent(this@MainActivity, ScreenCaptureService::class.java).apply {
                    action = ScreenCaptureService.ACTION_START_TAPPING
                    putExtra(ScreenCaptureService.EXTRA_PROFILE_ID, profile.id)
                }
                startService(tapIntent)

                AppLogger.log("Sesi auto-tap dimulai dengan profil: '${profile.name}'")
            }
        } else {
            Toast.makeText(this, "Izin Screen Capture ditolak. Gagal memulai.", Toast.LENGTH_LONG).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val db = AppDatabase.getDatabase(this)
        repository = ProfileRepository(db.autoTapDao())

        setContent {
            MyApplicationTheme {
                MainDashboardScreen(
                    repository = repository,
                    onStartProfile = { profile ->
                        if (!TapAccessibilityService.isRunning()) {
                            Toast.makeText(this@MainActivity, "⚠️ Harap aktifkan Layanan Aksesibilitas terlebih dahulu agar sentuhan otomatis berfungsi!", Toast.LENGTH_LONG).show()
                            val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
                            startActivity(intent)
                            return@MainDashboardScreen
                        }
                        if (profile.packageName.isNotEmpty()) {
                            val launchIntent = packageManager.getLaunchIntentForPackage(profile.packageName)
                            if (launchIntent == null) {
                                Toast.makeText(this@MainActivity, "Aplikasi target tidak ditemukan, mungkin sudah dihapus", Toast.LENGTH_LONG).show()
                            } else {
                                selectedProfileToStart = profile
                                requestScreenCapturePermission()
                            }
                        } else {
                            selectedProfileToStart = profile
                            requestScreenCapturePermission()
                        }
                    },
                    onStopAll = {
                        stopAllServices()
                    }
                )
            }
        }
    }

    private fun requestScreenCapturePermission() {
        val projectionManager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        screenCaptureLauncher.launch(projectionManager.createScreenCaptureIntent())
    }

    private fun stopAllServices() {
        val stopCaptureIntent = Intent(this, ScreenCaptureService::class.java).apply {
            action = ScreenCaptureService.ACTION_STOP
        }
        startService(stopCaptureIntent)

        val stopOverlayIntent = Intent(this, OverlayService::class.java)
        stopService(stopOverlayIntent)

        AppLogger.log("Sesi auto-tap dihentikan manual oleh pengguna.")
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainDashboardScreen(
    repository: ProfileRepository,
    onStartProfile: (Profile) -> Unit,
    onStopAll: () -> Unit
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    // Database Flows
    val profiles by repository.allProfiles.collectAsStateWithLifecycle(initialValue = emptyList())
    val activeServiceState by ScreenCaptureService.state.collectAsStateWithLifecycle()
    val activeProfileId by ScreenCaptureService.activeProfileId.collectAsStateWithLifecycle()

    // Local UI Permissions State (re-check on Resume)
    val powerManager = remember { context.getSystemService(Context.POWER_SERVICE) as? PowerManager }
    var isOverlayPermissionGranted by remember { mutableStateOf(Settings.canDrawOverlays(context)) }
    var isAccessibilityPermissionGranted by remember { mutableStateOf(TapAccessibilityService.isRunning()) }
    var isNotificationPermissionGranted by remember {
        mutableStateOf(
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
            } else true
        )
    }
    var isBatteryOptimizationIgnored by remember {
        mutableStateOf(
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                powerManager?.isIgnoringBatteryOptimizations(context.packageName) == true
            } else true
        )
    }
    var showAllPermissionsDetail by remember { mutableStateOf(false) }
    var showDiagnosticDialog by remember { mutableStateOf(false) }

    val notificationLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        isNotificationPermissionGranted = granted
    }

    // Live logs flow
    val logsList by AppLogger.logs.collectAsStateWithLifecycle()

    // Recheck permission states when screen gets focus / activity resumes
    val lifecycleOwner = LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                isOverlayPermissionGranted = Settings.canDrawOverlays(context)
                isAccessibilityPermissionGranted = TapAccessibilityService.isRunning()
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    isNotificationPermissionGranted = ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
                }
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    isBatteryOptimizationIgnored = powerManager?.isIgnoringBatteryOptimizations(context.packageName) == true
                }
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
        }
    }

    Scaffold(
        topBar = {
            // High-fidelity sci-fi immersive header
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(com.example.ui.theme.ObsidianBg)
                    .statusBarsPadding()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp, vertical = 16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        // High-tech circular scanner icon with subtle glow border
                        Box(
                            modifier = Modifier
                                .size(42.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(com.example.ui.theme.CyberCyan.copy(alpha = 0.15f))
                                .border(1.dp, com.example.ui.theme.CyberCyan.copy(alpha = 0.35f), RoundedCornerShape(12.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(20.dp)
                                    .border(2.dp, com.example.ui.theme.CyberCyan, RoundedCornerShape(10.dp)),
                                contentAlignment = Alignment.Center
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(6.dp)
                                        .background(com.example.ui.theme.CyberCyan, RoundedCornerShape(3.dp))
                                )
                            }
                        }

                        Column {
                            Text(
                                text = "Auto Tap",
                                fontWeight = FontWeight.Bold,
                                fontSize = 18.sp,
                                color = Color.White,
                                letterSpacing = (-0.5).sp
                            )
                            Text(
                                text = "IMAGE DETECTION V1.2",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = com.example.ui.theme.CyberCyan,
                                letterSpacing = 1.5.sp
                            )
                        }
                    }

                    // Top Action: Diagnostic Button + Quick Stop/Status button
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedButton(
                            onClick = { showDiagnosticDialog = true },
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = com.example.ui.theme.CyberCyan),
                            border = BorderStroke(1.dp, com.example.ui.theme.CyberCyan.copy(alpha = 0.5f)),
                            shape = RoundedCornerShape(10.dp),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                            modifier = Modifier.height(34.dp)
                        ) {
                            Icon(Icons.Default.BugReport, contentDescription = "Diagnostik", modifier = Modifier.size(15.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Diagnostik", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }

                        if (activeServiceState != ScreenCaptureService.ServiceState.STOPPED) {
                            OutlinedButton(
                                onClick = onStopAll,
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFEF4444)),
                                border = BorderStroke(1.dp, Color(0xFFEF4444).copy(alpha = 0.5f)),
                                shape = RoundedCornerShape(10.dp),
                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                                modifier = Modifier.height(34.dp)
                            ) {
                                Icon(Icons.Default.Stop, contentDescription = "Stop", modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("STOP", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        } else if (isOverlayPermissionGranted && isAccessibilityPermissionGranted) {
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(50.dp))
                                    .background(com.example.ui.theme.EmeraldReady.copy(alpha = 0.1f))
                                    .border(1.dp, com.example.ui.theme.EmeraldReady.copy(alpha = 0.3f), RoundedCornerShape(50.dp))
                                    .padding(horizontal = 10.dp, vertical = 4.dp)
                            ) {
                                Text(
                                    text = "READY",
                                    color = com.example.ui.theme.EmeraldReady,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
                
                // Fine glowing divider
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(1.dp)
                        .background(com.example.ui.theme.BorderSlate)
                )
            }
        },
        containerColor = com.example.ui.theme.ObsidianBg
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // ================= 1. PERMISSION CHECKS (STEP BY STEP) =================
            val allMandatoryGranted = isOverlayPermissionGranted && isAccessibilityPermissionGranted

            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(
                        1.dp,
                        if (allMandatoryGranted) com.example.ui.theme.EmeraldReady.copy(alpha = 0.35f)
                        else Color(0xFFF59E0B).copy(alpha = 0.5f),
                        RoundedCornerShape(16.dp)
                    ),
                colors = CardDefaults.cardColors(
                    containerColor = if (allMandatoryGranted) com.example.ui.theme.SlateCardBg
                    else Color(0xFF1E1B18)
                )
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // Header with Status Indicator
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Icon(
                                imageVector = if (allMandatoryGranted) Icons.Default.CheckCircle else Icons.Default.Shield,
                                contentDescription = null,
                                tint = if (allMandatoryGranted) com.example.ui.theme.EmeraldReady else Color(0xFFF59E0B),
                                modifier = Modifier.size(22.dp)
                            )
                            Column {
                                Text(
                                    text = if (allMandatoryGranted) "Status Izin: Lengkap & Siap Digunakan" else "Status Izin: Perlu Diaktifkan",
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White,
                                    fontSize = 14.sp
                                )
                                Text(
                                    text = if (allMandatoryGranted) "Semua izin utama sudah aktif ✅" else "Aktifkan izin secara berurutan di bawah ini",
                                    fontSize = 11.sp,
                                    color = com.example.ui.theme.TextMuted
                                )
                            }
                        }

                        if (allMandatoryGranted) {
                            TextButton(
                                onClick = { showAllPermissionsDetail = !showAllPermissionsDetail },
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = if (showAllPermissionsDetail) "Tutup ▲" else "Detail ▼",
                                    fontSize = 11.sp,
                                    color = com.example.ui.theme.CyberCyan,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }

                    if (!allMandatoryGranted || showAllPermissionsDetail) {
                        HorizontalDivider(color = com.example.ui.theme.BorderSlate, thickness = 1.dp)

                        // STEP 1: OVERLAY PERMISSION
                        PermissionStepItem(
                            stepNumber = 1,
                            title = "Izin Tampilan di Atas Aplikasi Lain (Overlay)",
                            description = "Diperlukan untuk memunculkan tombol melayang, menu kontrol, dan pin target di atas layar.",
                            isGranted = isOverlayPermissionGranted,
                            buttonText = "Aktifkan Izin 1",
                            onActionClick = {
                                try {
                                    val intent = Intent(
                                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                        Uri.parse("package:${context.packageName}")
                                    )
                                    context.startActivity(intent)
                                } catch (e: Exception) {
                                    context.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION))
                                }
                            }
                        )

                        // STEP 2: ACCESSIBILITY SERVICE (CRITICAL FOR CLICKS)
                        PermissionStepItem(
                            stepNumber = 2,
                            title = "Layanan Aksesibilitas (Auto Tap Gesture)",
                            description = "Sangat Penting! Diperlukan agar robot sistem Android dapat menekan/mengklik tombol target secara otomatis.",
                            isGranted = isAccessibilityPermissionGranted,
                            buttonText = "Aktifkan Izin 2",
                            guideHint = "Buka menu, cari 'Auto Tap by Image', lalu nyalakan tombol Aktif.",
                            secondaryButtonText = "🧪 Uji Coba Ketukan (Mode Diagnostik)",
                            onSecondaryClick = { showDiagnosticDialog = true },
                            onActionClick = {
                                val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
                                context.startActivity(intent)
                            }
                        )

                        // STEP 3: NOTIFICATIONS (ANDROID 13+)
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                            PermissionStepItem(
                                stepNumber = 3,
                                title = "Izin Notifikasi (Android 13+)",
                                description = "Menjaga proses auto-clicker tetap berjalan lancar di bar notifikasi.",
                                isGranted = isNotificationPermissionGranted,
                                buttonText = "Aktifkan Izin 3",
                                onActionClick = {
                                    notificationLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                                }
                            )
                        }

                        // STEP 4: BATTERY OPTIMIZATION
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                            PermissionStepItem(
                                stepNumber = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) 4 else 3,
                                title = "Abaikan Hemat Baterai (Latar Belakang)",
                                description = "Mencegah sistem HP mematikan auto-clicker saat game berat berjalan.",
                                isGranted = isBatteryOptimizationIgnored,
                                buttonText = "Beri Izin",
                                onActionClick = {
                                    try {
                                        val intent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
                                            data = Uri.parse("package:${context.packageName}")
                                        }
                                        context.startActivity(intent)
                                    } catch (e: Exception) {
                                        Toast.makeText(context, "Buka Pengaturan Baterai untuk mengabaikan hemat daya.", Toast.LENGTH_SHORT).show()
                                    }
                                }
                            )
                        }
                    }
                }
            }

            // ================= 2. ACTIVE ENGINE CONTROL CARD =================
            val statusColor = when (activeServiceState) {
                ScreenCaptureService.ServiceState.STOPPED -> com.example.ui.theme.BorderSlate
                ScreenCaptureService.ServiceState.IDLE -> com.example.ui.theme.CyberCyan
                ScreenCaptureService.ServiceState.RUNNING -> com.example.ui.theme.EmeraldReady
                ScreenCaptureService.ServiceState.PAUSED -> com.example.ui.theme.WarningGold
            }

            val statusLabel = when (activeServiceState) {
                ScreenCaptureService.ServiceState.STOPPED -> "OFFLINE"
                ScreenCaptureService.ServiceState.IDLE -> "STANDBY"
                ScreenCaptureService.ServiceState.RUNNING -> "ACTIVE SCANNING"
                ScreenCaptureService.ServiceState.PAUSED -> "SUSPENDED"
            }

            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, statusColor.copy(alpha = 0.35f), RoundedCornerShape(20.dp)),
                colors = CardDefaults.cardColors(containerColor = com.example.ui.theme.SlateCardBg)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            // Pulsing radar-like dot
                            Box(
                                modifier = Modifier
                                    .size(12.dp)
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(statusColor)
                            )
                            Column {
                                Text(
                                    "Mesin Deteksi Auto-Tap",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp,
                                    color = Color.White
                                )
                                Text(
                                    text = when (activeServiceState) {
                                        ScreenCaptureService.ServiceState.STOPPED -> "Sistem offline. Jalankan salah satu profil di bawah."
                                        ScreenCaptureService.ServiceState.IDLE -> "Overlay aktif. Menunggu pemicu start di layar."
                                        ScreenCaptureService.ServiceState.RUNNING -> "Sedang mencari kecocokan visual real-time..."
                                        ScreenCaptureService.ServiceState.PAUSED -> "Pemindaian visual ditangguhkan sementara."
                                    },
                                    fontSize = 12.sp,
                                    color = com.example.ui.theme.TextMuted
                                )
                            }
                        }

                        // High-tech status tag
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(statusColor.copy(alpha = 0.12f))
                                .border(1.dp, statusColor.copy(alpha = 0.3f), RoundedCornerShape(6.dp))
                                .padding(horizontal = 10.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = statusLabel,
                                color = statusColor,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 0.5.sp
                            )
                        }
                    }

                    // If active, show an integrated OFF switch bar at the bottom
                    if (activeServiceState != ScreenCaptureService.ServiceState.STOPPED) {
                        Button(
                            onClick = onStopAll,
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFEF4444).copy(alpha = 0.15f), contentColor = Color(0xFFF87171)),
                            border = BorderStroke(1.dp, Color(0xFFEF4444).copy(alpha = 0.35f)),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Icon(Icons.Default.PowerSettingsNew, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("NONAKTIFKAN MESIN DETEKSI", fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 0.5.sp)
                        }
                    }
                }
            }

            // ================= 3. PROFILE LIST HEADER =================
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Profil Deteksi",
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp,
                    color = Color.White
                )
                
                OutlinedButton(
                    onClick = {
                        val intent = Intent(context, ProfileEditorActivity::class.java)
                        context.startActivity(intent)
                    },
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = com.example.ui.theme.CyberCyan),
                    border = BorderStroke(1.dp, com.example.ui.theme.CyberCyan.copy(alpha = 0.6f)),
                    shape = RoundedCornerShape(12.dp),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                    modifier = Modifier.height(36.dp)
                ) {
                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Profil Baru", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }

            // ================= 4. PROFILES LISTING =================
            if (profiles.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                        .border(1.dp, com.example.ui.theme.BorderSlate, RoundedCornerShape(16.dp))
                        .background(com.example.ui.theme.SlateCardBg.copy(alpha = 0.5f))
                        .padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            Icons.Default.CreateNewFolder, 
                            contentDescription = null, 
                            modifier = Modifier.size(44.dp), 
                            tint = com.example.ui.theme.TextMuted
                        )
                        Text(
                            "Belum ada profil", 
                            fontWeight = FontWeight.Bold, 
                            color = com.example.ui.theme.TextLight,
                            fontSize = 14.sp
                        )
                        Text(
                            "Buat profil baru dan tambahkan gambar target tombol untuk mulai deteksi otomatis.", 
                            fontSize = 11.sp, 
                            color = com.example.ui.theme.TextMuted,
                            modifier = Modifier.padding(horizontal = 16.dp)
                        )
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(profiles) { profile ->
                        val isThisProfileActive = activeProfileId == profile.id && activeServiceState != ScreenCaptureService.ServiceState.STOPPED
                        
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .border(
                                    width = 1.2.dp,
                                    color = if (isThisProfileActive) com.example.ui.theme.CyberCyan else com.example.ui.theme.BorderSlate,
                                    shape = RoundedCornerShape(16.dp)
                                ),
                            colors = CardDefaults.cardColors(containerColor = com.example.ui.theme.SlateCardBg)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(14.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        Text(
                                            text = profile.name, 
                                            fontWeight = FontWeight.Bold, 
                                            fontSize = 16.sp,
                                            color = if (isThisProfileActive) com.example.ui.theme.CyberCyan else Color.White
                                        )
                                        if (isThisProfileActive) {
                                            Box(
                                                modifier = Modifier
                                                    .clip(RoundedCornerShape(4.dp))
                                                    .background(com.example.ui.theme.CyberCyan.copy(alpha = 0.15f))
                                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                                            ) {
                                                Text(
                                                    "ACTIVE",
                                                    color = com.example.ui.theme.CyberCyan,
                                                    fontSize = 8.sp,
                                                    fontWeight = FontWeight.Bold
                                                )
                                            }
                                        }
                                    }
                                    if (profile.packageName.isNotEmpty()) {
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.Android,
                                                contentDescription = null,
                                                tint = com.example.ui.theme.CyberCyan,
                                                modifier = Modifier.size(14.dp)
                                            )
                                            Text(
                                                text = profile.appName,
                                                fontSize = 11.sp,
                                                fontWeight = FontWeight.Medium,
                                                color = com.example.ui.theme.TextLight
                                            )
                                        }
                                    }
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        "Interval capture: ${profile.captureIntervalMs}ms", 
                                        fontSize = 12.sp, 
                                        color = com.example.ui.theme.TextMuted
                                    )
                                }

                                Row(
                                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    // Start Button
                                    IconButton(
                                        onClick = {
                                            if (!isOverlayPermissionGranted || !isAccessibilityPermissionGranted) {
                                                Toast.makeText(context, "Berikan semua izin sistem terlebih dahulu!", Toast.LENGTH_SHORT).show()
                                                return@IconButton
                                            }
                                            coroutineScope.launch {
                                                val relation = repository.getProfileWithTargetsDirect(profile.id)
                                                relation?.targets?.forEach { target ->
                                                    repository.updateTargetImage(target.copy(tapCount = 0))
                                                }
                                                onStartProfile(profile)
                                            }
                                        },
                                        enabled = activeServiceState == ScreenCaptureService.ServiceState.STOPPED
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.PlayArrow, 
                                            contentDescription = "Jalankan", 
                                            tint = if (activeServiceState == ScreenCaptureService.ServiceState.STOPPED) com.example.ui.theme.EmeraldReady else com.example.ui.theme.TextMuted,
                                            modifier = Modifier.size(24.dp)
                                        )
                                    }

                                    // Edit Button
                                    IconButton(
                                        onClick = {
                                            val intent = Intent(context, ProfileEditorActivity::class.java).apply {
                                                putExtra(ProfileEditorActivity.EXTRA_PROFILE_ID, profile.id)
                                            }
                                            context.startActivity(intent)
                                        }
                                    ) {
                                        Icon(
                                            Icons.Default.Edit, 
                                            contentDescription = "Edit", 
                                            tint = com.example.ui.theme.CyberCyan,
                                            modifier = Modifier.size(20.dp)
                                        )
                                    }

                                    // Delete Button
                                    IconButton(
                                        onClick = {
                                            coroutineScope.launch {
                                                val relation = repository.getProfileWithTargetsDirect(profile.id)
                                                relation?.targets?.forEach { target ->
                                                    File(target.filePath).delete()
                                                }
                                                repository.deleteProfile(profile)
                                                Toast.makeText(context, "Profil dihapus", Toast.LENGTH_SHORT).show()
                                            }
                                        },
                                        enabled = activeServiceState == ScreenCaptureService.ServiceState.STOPPED
                                    ) {
                                        Icon(
                                            Icons.Default.Delete, 
                                            contentDescription = "Hapus", 
                                            tint = if (activeServiceState == ScreenCaptureService.ServiceState.STOPPED) Color(0xFFEF4444) else com.example.ui.theme.TextMuted,
                                            modifier = Modifier.size(20.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // ================= 5. LIVE LOGGER VIEW =================
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(190.dp)
                    .border(1.dp, com.example.ui.theme.BorderSlate, RoundedCornerShape(16.dp)),
                colors = CardDefaults.cardColors(containerColor = com.example.ui.theme.ConsoleBg)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(6.dp)
                                    .clip(RoundedCornerShape(3.dp))
                                    .background(com.example.ui.theme.EmeraldReady)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                "KONSOL LOG AKTIVITAS", 
                                color = Color.White, 
                                fontSize = 11.sp, 
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 0.5.sp
                            )
                        }
                        IconButton(
                            onClick = { AppLogger.clear() },
                            modifier = Modifier.size(28.dp)
                        ) {
                            Icon(
                                Icons.Default.DeleteSweep, 
                                contentDescription = "Bersihkan Log", 
                                tint = com.example.ui.theme.TextMuted, 
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(Color.Black.copy(alpha = 0.3f), RoundedCornerShape(8.dp))
                            .padding(10.dp)
                    ) {
                        if (logsList.isEmpty()) {
                            Box(
                                modifier = Modifier.fillMaxSize(),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    "Menunggu aktivitas mesin auto-tap...", 
                                    color = com.example.ui.theme.TextMuted, 
                                    fontSize = 11.sp, 
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                        } else {
                            LazyColumn(modifier = Modifier.fillMaxSize()) {
                                items(logsList) { logLine ->
                                    val logColor = when {
                                        logLine.contains("⚠️") || logLine.contains("Error") -> Color(0xFFEF4444)
                                        logLine.contains("Match found") || logLine.contains("Click") || logLine.contains("Berhasil") -> com.example.ui.theme.EmeraldReady
                                        logLine.contains("Sesi") || logLine.contains("mulai") -> com.example.ui.theme.CyberCyan
                                        else -> com.example.ui.theme.TextMuted
                                    }
                                    Text(
                                        text = logLine,
                                        color = logColor,
                                        fontSize = 10.sp,
                                        fontFamily = FontFamily.Monospace,
                                        modifier = Modifier.padding(bottom = 3.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showDiagnosticDialog) {
        DiagnosticModeDialog(
            onDismiss = { showDiagnosticDialog = false }
        )
    }
}

@Composable
fun PermissionStepItem(
    stepNumber: Int,
    title: String,
    description: String,
    isGranted: Boolean,
    buttonText: String,
    guideHint: String? = null,
    secondaryButtonText: String? = null,
    onSecondaryClick: (() -> Unit)? = null,
    onActionClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .border(
                1.dp,
                if (isGranted) com.example.ui.theme.EmeraldReady.copy(alpha = 0.3f)
                else com.example.ui.theme.BorderSlate,
                RoundedCornerShape(12.dp)
            ),
        colors = CardDefaults.cardColors(
            containerColor = if (isGranted) com.example.ui.theme.EmeraldReady.copy(alpha = 0.05f)
            else com.example.ui.theme.SlateCardBg
        )
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Box(
                        modifier = Modifier
                            .size(24.dp)
                            .clip(RoundedCornerShape(6.dp))
                            .background(
                                if (isGranted) com.example.ui.theme.EmeraldReady.copy(alpha = 0.2f)
                                else com.example.ui.theme.CyberCyan.copy(alpha = 0.2f)
                            )
                            .border(
                                1.dp,
                                if (isGranted) com.example.ui.theme.EmeraldReady
                                else com.example.ui.theme.CyberCyan,
                                RoundedCornerShape(6.dp)
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "$stepNumber",
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp,
                            color = if (isGranted) com.example.ui.theme.EmeraldReady else com.example.ui.theme.CyberCyan
                        )
                    }

                    Text(
                        text = title,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        color = Color.White
                    )
                }

                // Status Badge
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(
                            if (isGranted) com.example.ui.theme.EmeraldReady.copy(alpha = 0.15f)
                            else Color(0xFFEF4444).copy(alpha = 0.15f)
                        )
                        .border(
                            1.dp,
                            if (isGranted) com.example.ui.theme.EmeraldReady.copy(alpha = 0.4f)
                            else Color(0xFFEF4444).copy(alpha = 0.4f),
                            RoundedCornerShape(6.dp)
                        )
                        .padding(horizontal = 8.dp, vertical = 3.dp)
                ) {
                    Text(
                        text = if (isGranted) "AKTIF ✓" else "BELUM ✕",
                        color = if (isGranted) com.example.ui.theme.EmeraldReady else Color(0xFFF87171),
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Text(
                text = description,
                fontSize = 11.sp,
                color = com.example.ui.theme.TextMuted,
                lineHeight = 15.sp
            )

            if (!isGranted && guideHint != null) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color(0xFFF59E0B).copy(alpha = 0.1f), RoundedCornerShape(6.dp))
                        .padding(horizontal = 8.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = "💡 Petunjuk: $guideHint",
                        fontSize = 10.sp,
                        color = Color(0xFFFDE68A)
                    )
                }
            }

            if (!isGranted) {
                Button(
                    onClick = onActionClick,
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = com.example.ui.theme.CyberCyan,
                        contentColor = Color.Black
                    ),
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(vertical = 8.dp)
                ) {
                    Text(buttonText, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }
            }

            if (secondaryButtonText != null && onSecondaryClick != null) {
                OutlinedButton(
                    onClick = onSecondaryClick,
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = com.example.ui.theme.CyberCyan),
                    border = BorderStroke(1.dp, com.example.ui.theme.CyberCyan.copy(alpha = 0.5f)),
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(vertical = 6.dp)
                ) {
                    Icon(Icons.Default.BugReport, contentDescription = null, modifier = Modifier.size(15.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(secondaryButtonText, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                }
            }
        }
    }
}
