package com.example.ui

import android.content.Context
import android.content.Intent
import android.provider.Settings
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.boundsInWindow
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.service.TapAccessibilityService
import com.example.ui.theme.*
import com.example.util.AppLogger
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

data class DiagnosticLogEntry(
    val id: String = UUID.randomUUID().toString(),
    val timestamp: String,
    val type: String,
    val coordinates: String,
    val isSuccess: Boolean,
    val latencyMs: Long,
    val message: String
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DiagnosticModeDialog(
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val configuration = LocalConfiguration.current
    val density = LocalDensity.current
    val coroutineScope = rememberCoroutineScope()

    // Screen dimensions in pixels
    val screenWidthPx = with(density) { configuration.screenWidthDp.dp.toPx() }
    val screenHeightPx = with(density) { configuration.screenHeightDp.dp.toPx() }

    // Service Status
    var isServiceActive by remember { mutableStateOf(TapAccessibilityService.isRunning()) }

    // Diagnostic Tabs (0: Target Button Test, 1: Custom Coordinates, 2: Touch Canvas Arena)
    var selectedTab by remember { mutableIntStateOf(0) }

    // Interactive Target Button State
    var targetButtonCenterX by remember { mutableFloatStateOf(0f) }
    var targetButtonCenterY by remember { mutableFloatStateOf(0f) }
    var targetClicksReceived by remember { mutableIntStateOf(0) }
    var lastTargetClickTime by remember { mutableStateOf<String?>(null) }
    var isTargetTesting by remember { mutableStateOf(false) }

    // Custom Coordinate Inputs
    var inputX by remember { mutableStateOf((screenWidthPx / 2f).toInt().toString()) }
    var inputY by remember { mutableStateOf((screenHeightPx / 2f).toInt().toString()) }
    var selectedGestureType by remember { mutableStateOf("TAP") } // TAP, LONG_500, LONG_1000, DOUBLE_TAP, SEQUENCE
    var isCustomTesting by remember { mutableStateOf(false) }

    // Canvas Coordinate Picker
    var canvasSelectedX by remember { mutableFloatStateOf(screenWidthPx / 2f) }
    var canvasSelectedY by remember { mutableFloatStateOf(screenHeightPx / 2f) }

    // Diagnostic Logs
    val diagnosticLogs = remember { mutableStateListOf<DiagnosticLogEntry>() }

    val timeFormat = remember { SimpleDateFormat("HH:mm:ss.SSS", Locale.getDefault()) }

    fun addDiagnosticLog(type: String, coords: String, success: Boolean, latencyMs: Long, message: String) {
        val entry = DiagnosticLogEntry(
            timestamp = timeFormat.format(Date()),
            type = type,
            coordinates = coords,
            isSuccess = success,
            latencyMs = latencyMs,
            message = message
        )
        diagnosticLogs.add(0, entry)
        if (diagnosticLogs.size > 50) {
            diagnosticLogs.removeLast()
        }
        AppLogger.log("[DIAGNOSTIK] $type pada $coords -> ${if (success) "SUKSES" else "GAGAL"} (${latencyMs}ms): $message")
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(
            usePlatformDefaultWidth = false,
            dismissOnBackPress = true,
            dismissOnClickOutside = false
        )
    ) {
        Surface(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 8.dp, vertical = 20.dp),
            shape = RoundedCornerShape(24.dp),
            color = ObsidianBg,
            border = androidx.compose.foundation.BorderStroke(1.5.dp, CyberCyan.copy(alpha = 0.4f))
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Header with high-tech badge and close button
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(CyberCyan.copy(alpha = 0.15f))
                                .border(1.dp, CyberCyan, RoundedCornerShape(10.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.BugReport,
                                contentDescription = null,
                                tint = CyberCyan,
                                modifier = Modifier.size(20.dp)
                            )
                        }

                        Column {
                            Text(
                                text = "Mode Diagnostik Sentuhan",
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp,
                                color = Color.White
                            )
                            Text(
                                text = "Uji Coba Langsung Layanan Aksesibilitas",
                                fontSize = 11.sp,
                                color = CyberCyan
                            )
                        }
                    }

                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier
                            .size(36.dp)
                            .background(SlateCardBg, CircleShape)
                            .border(1.dp, BorderSlate, CircleShape)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Tutup",
                            tint = TextLight,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }

                // 1. Live Accessibility Service Status Card
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(
                            1.dp,
                            if (isServiceActive) EmeraldReady.copy(alpha = 0.4f) else Color(0xFFEF4444).copy(alpha = 0.5f),
                            RoundedCornerShape(14.dp)
                        ),
                    colors = CardDefaults.cardColors(
                        containerColor = if (isServiceActive) EmeraldReady.copy(alpha = 0.08f) else Color(0xFF1E1414)
                    )
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(12.dp)
                                    .clip(CircleShape)
                                    .background(if (isServiceActive) EmeraldReady else Color(0xFFEF4444))
                            )
                            Column {
                                Text(
                                    text = if (isServiceActive) "Aksesibilitas Aktif & Siap Disimulasikan" else "Layanan Aksesibilitas Belum Aktif",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp,
                                    color = Color.White
                                )
                                Text(
                                    text = if (isServiceActive) "TapAccessibilityService terhubung ke sistem OS Android" else "Perlu diaktifkan agar robot dapat mengirim ketukan",
                                    fontSize = 10.sp,
                                    color = TextMuted
                                )
                            }
                        }

                        if (!isServiceActive) {
                            Button(
                                onClick = {
                                    val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
                                    context.startActivity(intent)
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFEF4444)),
                                shape = RoundedCornerShape(8.dp),
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                                modifier = Modifier.height(32.dp)
                            ) {
                                Text("Buka Pengaturan", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            }
                        } else {
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(EmeraldReady.copy(alpha = 0.2f))
                                    .border(1.dp, EmeraldReady.copy(alpha = 0.5f), RoundedCornerShape(6.dp))
                                    .padding(horizontal = 8.dp, vertical = 3.dp)
                            ) {
                                Text("ONLINE ✓", color = EmeraldReady, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }

                // Tab Selector
                TabRow(
                    selectedTabIndex = selectedTab,
                    containerColor = SlateCardBg,
                    contentColor = CyberCyan,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .border(1.dp, BorderSlate, RoundedCornerShape(12.dp))
                ) {
                    Tab(
                        selected = selectedTab == 0,
                        onClick = { selectedTab = 0 },
                        text = { Text("Tombol Sasaran", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                        icon = { Icon(Icons.Default.TouchApp, contentDescription = null, modifier = Modifier.size(16.dp)) }
                    )
                    Tab(
                        selected = selectedTab == 1,
                        onClick = { selectedTab = 1 },
                        text = { Text("Input Koordinat", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                        icon = { Icon(Icons.Default.PinDrop, contentDescription = null, modifier = Modifier.size(16.dp)) }
                    )
                    Tab(
                        selected = selectedTab == 2,
                        onClick = { selectedTab = 2 },
                        text = { Text("Kanvas Sentuh", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                        icon = { Icon(Icons.Default.CenterFocusStrong, contentDescription = null, modifier = Modifier.size(16.dp)) }
                    )
                }

                // Main Interactive Panel Container (Scrollable Content)
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                ) {
                    when (selectedTab) {
                        0 -> {
                            // ================= TAB 0: INTERACTIVE TARGET BUTTON TEST =================
                            Column(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .verticalScroll(rememberScrollState()),
                                verticalArrangement = Arrangement.spacedBy(14.dp)
                            ) {
                                Text(
                                    text = "Uji Coba Langsung Tombol Target",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp,
                                    color = Color.White
                                )
                                Text(
                                    text = "Tekan tombol pemicu di bawah. Layanan Aksesibilitas akan mengirimkan ketukan fisik ke koordinat persis Tombol Target. Jika Aksesibilitas berfungsi, tombol sasaran akan menerima sentuhan dan menambah counter klik.",
                                    fontSize = 11.sp,
                                    color = TextMuted,
                                    lineHeight = 15.sp
                                )

                                // Target Button Display Box
                                Card(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .border(1.dp, BorderSlate, RoundedCornerShape(16.dp)),
                                    colors = CardDefaults.cardColors(containerColor = SlateCardBg)
                                ) {
                                    Column(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(16.dp),
                                        horizontalAlignment = Alignment.CenterHorizontally,
                                        verticalArrangement = Arrangement.spacedBy(12.dp)
                                    ) {
                                        Text(
                                            text = "🎯 TOMBOL TARGET FISIK (TARGET BUTTON)",
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = CyberCyan
                                        )

                                        // The Actual Physical Button to be tapped by AccessibilityService
                                        Button(
                                            onClick = {
                                                targetClicksReceived++
                                                lastTargetClickTime = timeFormat.format(Date())
                                                AppLogger.log("✅ Tombol sasaran berhasil menerima event klik fisik! Total klik: $targetClicksReceived")
                                            },
                                            modifier = Modifier
                                                .fillMaxWidth(0.85f)
                                                .height(64.dp)
                                                .onGloballyPositioned { coordinates ->
                                                    val bounds = coordinates.boundsInWindow()
                                                    targetButtonCenterX = bounds.left + (bounds.width / 2f)
                                                    targetButtonCenterY = bounds.top + (bounds.height / 2f)
                                                },
                                            shape = RoundedCornerShape(16.dp),
                                            colors = ButtonDefaults.buttonColors(
                                                containerColor = if (targetClicksReceived > 0) EmeraldReady else CyberCyan,
                                                contentColor = Color.Black
                                            ),
                                            elevation = ButtonDefaults.buttonElevation(defaultElevation = 6.dp)
                                        ) {
                                            Row(
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Default.RadioButtonChecked,
                                                    contentDescription = null,
                                                    modifier = Modifier.size(24.dp)
                                                )
                                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                                    Text(
                                                        text = "SASARAN SENTUHAN",
                                                        fontWeight = FontWeight.Black,
                                                        fontSize = 13.sp
                                                    )
                                                    Text(
                                                        text = "Klik Diterima: $targetClicksReceived kali",
                                                        fontWeight = FontWeight.Bold,
                                                        fontSize = 11.sp
                                                    )
                                                }
                                            }
                                        }

                                        // Coordinates Display Info
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .background(ConsoleBg, RoundedCornerShape(8.dp))
                                                .padding(8.dp),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text(
                                                text = "Koordinat Layar: (${targetButtonCenterX.toInt()}px, ${targetButtonCenterY.toInt()}px)",
                                                fontFamily = FontFamily.Monospace,
                                                fontSize = 11.sp,
                                                color = CyberCyan
                                            )
                                            if (lastTargetClickTime != null) {
                                                Text(
                                                    text = "Waktu: $lastTargetClickTime",
                                                    fontFamily = FontFamily.Monospace,
                                                    fontSize = 10.sp,
                                                    color = EmeraldReady
                                                )
                                            }
                                        }
                                    }
                                }

                                // Trigger Button
                                Button(
                                    onClick = {
                                        if (!TapAccessibilityService.isRunning()) {
                                            Toast.makeText(context, "Layanan Aksesibilitas belum aktif!", Toast.LENGTH_SHORT).show()
                                            addDiagnosticLog("TARGET_TAP", "(${targetButtonCenterX.toInt()}, ${targetButtonCenterY.toInt()})", false, 0L, "Layanan Aksesibilitas belum berjalan")
                                            return@Button
                                        }
                                        if (targetButtonCenterX <= 0f || targetButtonCenterY <= 0f) {
                                            Toast.makeText(context, "Menunggu pengukuran koordinat tombol...", Toast.LENGTH_SHORT).show()
                                            return@Button
                                        }

                                        isTargetTesting = true
                                        val startTime = System.currentTimeMillis()
                                        coroutineScope.launch {
                                            val initialCount = targetClicksReceived
                                            val success = TapAccessibilityService.performTapSuspend(targetButtonCenterX, targetButtonCenterY)
                                            val elapsed = System.currentTimeMillis() - startTime
                                            delay(100) // wait for UI click event propagation
                                            val countAfter = targetClicksReceived

                                            isTargetTesting = false
                                            if (success) {
                                                if (countAfter > initialCount) {
                                                    addDiagnosticLog("TARGET_TAP", "(${targetButtonCenterX.toInt()}, ${targetButtonCenterY.toInt()})", true, elapsed, "Gestur terkirim & klik fisik sukses diverifikasi oleh Tombol Sasaran! ✓")
                                                } else {
                                                    addDiagnosticLog("TARGET_TAP", "(${targetButtonCenterX.toInt()}, ${targetButtonCenterY.toInt()})", true, elapsed, "Gestur terkirim ke OS, menunggu registrasi UI.")
                                                }
                                            } else {
                                                addDiagnosticLog("TARGET_TAP", "(${targetButtonCenterX.toInt()}, ${targetButtonCenterY.toInt()})", false, elapsed, "OS membatalkan gestur ketukan.")
                                            }
                                        }
                                    },
                                    modifier = Modifier.fillMaxWidth(),
                                    enabled = !isTargetTesting,
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = EmeraldReady,
                                        contentColor = Color.Black
                                    ),
                                    shape = RoundedCornerShape(12.dp),
                                    contentPadding = PaddingValues(vertical = 12.dp)
                                ) {
                                    if (isTargetTesting) {
                                        CircularProgressIndicator(modifier = Modifier.size(18.dp), color = Color.Black, strokeWidth = 2.dp)
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text("Mengirimkan Ketukan Gestur...", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                    } else {
                                        Icon(Icons.Default.Send, contentDescription = null, modifier = Modifier.size(18.dp))
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text("KIRIM KETUKAN KE TOMBOL SASARAN", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                    }
                                }

                                // Reset Counter Button
                                if (targetClicksReceived > 0) {
                                    OutlinedButton(
                                        onClick = {
                                            targetClicksReceived = 0
                                            lastTargetClickTime = null
                                        },
                                        modifier = Modifier.fillMaxWidth(),
                                        border = androidx.compose.foundation.BorderStroke(1.dp, BorderSlate),
                                        shape = RoundedCornerShape(10.dp),
                                        colors = ButtonDefaults.outlinedButtonColors(contentColor = TextMuted)
                                    ) {
                                        Text("Reset Counter Sasaran", fontSize = 11.sp)
                                    }
                                }
                            }
                        }

                        1 -> {
                            // ================= TAB 1: CUSTOM COORDINATES INPUT =================
                            Column(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .verticalScroll(rememberScrollState()),
                                verticalArrangement = Arrangement.spacedBy(14.dp)
                            ) {
                                Text(
                                    text = "Uji Koordinat Layar Manual",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp,
                                    color = Color.White
                                )

                                // Preset Shortcuts
                                Text("Pintasan Posisi:", fontSize = 11.sp, color = TextMuted, fontWeight = FontWeight.SemiBold)
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Button(
                                        onClick = {
                                            inputX = (screenWidthPx / 2f).toInt().toString()
                                            inputY = (screenHeightPx / 2f).toInt().toString()
                                        },
                                        modifier = Modifier.weight(1f),
                                        colors = ButtonDefaults.buttonColors(containerColor = SlateCardBg, contentColor = CyberCyan),
                                        border = androidx.compose.foundation.BorderStroke(1.dp, CyberCyan.copy(alpha = 0.5f)),
                                        shape = RoundedCornerShape(8.dp),
                                        contentPadding = PaddingValues(vertical = 4.dp)
                                    ) {
                                        Text("Pusat Layar", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                    }

                                    Button(
                                        onClick = {
                                            inputX = (screenWidthPx / 2f).toInt().toString()
                                            inputY = (screenHeightPx * 0.25f).toInt().toString()
                                        },
                                        modifier = Modifier.weight(1f),
                                        colors = ButtonDefaults.buttonColors(containerColor = SlateCardBg, contentColor = TextLight),
                                        border = androidx.compose.foundation.BorderStroke(1.dp, BorderSlate),
                                        shape = RoundedCornerShape(8.dp),
                                        contentPadding = PaddingValues(vertical = 4.dp)
                                    ) {
                                        Text("Area Atas", fontSize = 10.sp)
                                    }

                                    Button(
                                        onClick = {
                                            inputX = (screenWidthPx / 2f).toInt().toString()
                                            inputY = (screenHeightPx * 0.75f).toInt().toString()
                                        },
                                        modifier = Modifier.weight(1f),
                                        colors = ButtonDefaults.buttonColors(containerColor = SlateCardBg, contentColor = TextLight),
                                        border = androidx.compose.foundation.BorderStroke(1.dp, BorderSlate),
                                        shape = RoundedCornerShape(8.dp),
                                        contentPadding = PaddingValues(vertical = 4.dp)
                                    ) {
                                        Text("Area Bawah", fontSize = 10.sp)
                                    }
                                }

                                // Coordinate Text Inputs
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    OutlinedTextField(
                                        value = inputX,
                                        onValueChange = { inputX = it.filter { char -> char.isDigit() } },
                                        label = { Text("Koordinat X (px)") },
                                        modifier = Modifier.weight(1f),
                                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                        singleLine = true,
                                        colors = OutlinedTextFieldDefaults.colors(
                                            focusedBorderColor = CyberCyan,
                                            unfocusedBorderColor = BorderSlate,
                                            focusedTextColor = Color.White,
                                            unfocusedTextColor = Color.White,
                                            focusedLabelColor = CyberCyan
                                        ),
                                        shape = RoundedCornerShape(10.dp)
                                    )

                                    OutlinedTextField(
                                        value = inputY,
                                        onValueChange = { inputY = it.filter { char -> char.isDigit() } },
                                        label = { Text("Koordinat Y (px)") },
                                        modifier = Modifier.weight(1f),
                                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                        singleLine = true,
                                        colors = OutlinedTextFieldDefaults.colors(
                                            focusedBorderColor = CyberCyan,
                                            unfocusedBorderColor = BorderSlate,
                                            focusedTextColor = Color.White,
                                            unfocusedTextColor = Color.White,
                                            focusedLabelColor = CyberCyan
                                        ),
                                        shape = RoundedCornerShape(10.dp)
                                    )
                                }

                                // Gesture Type Selection
                                Text("Tipe Aksi Gestur:", fontSize = 11.sp, color = TextMuted, fontWeight = FontWeight.SemiBold)
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    listOf(
                                        "TAP" to "Ketuk (80ms)",
                                        "LONG_500" to "Tahan (500ms)",
                                        "LONG_1000" to "Tahan (1s)",
                                        "DOUBLE_TAP" to "Ganda (2x)"
                                    ).forEach { (type, label) ->
                                        val isSelected = selectedGestureType == type
                                        Box(
                                            modifier = Modifier
                                                .weight(1f)
                                                .clip(RoundedCornerShape(8.dp))
                                                .background(if (isSelected) CyberCyan.copy(alpha = 0.2f) else SlateCardBg)
                                                .border(
                                                    1.dp,
                                                    if (isSelected) CyberCyan else BorderSlate,
                                                    RoundedCornerShape(8.dp)
                                                )
                                                .clickable { selectedGestureType = type }
                                                .padding(vertical = 8.dp),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Text(
                                                text = label,
                                                fontSize = 9.sp,
                                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                                color = if (isSelected) CyberCyan else TextLight,
                                                textAlign = TextAlign.Center
                                            )
                                        }
                                    }
                                }

                                // Execution Button
                                Button(
                                    onClick = {
                                        val x = inputX.toFloatOrNull() ?: 0f
                                        val y = inputY.toFloatOrNull() ?: 0f

                                        if (!TapAccessibilityService.isRunning()) {
                                            Toast.makeText(context, "Layanan Aksesibilitas belum aktif!", Toast.LENGTH_SHORT).show()
                                            addDiagnosticLog("CUSTOM_$selectedGestureType", "(${x.toInt()}, ${y.toInt()})", false, 0L, "Layanan Aksesibilitas belum berjalan")
                                            return@Button
                                        }

                                        isCustomTesting = true
                                        coroutineScope.launch {
                                            val startTime = System.currentTimeMillis()
                                            val success: Boolean
                                            when (selectedGestureType) {
                                                "LONG_500" -> {
                                                    success = TapAccessibilityService.performLongPressSuspend(x, y, 500L)
                                                }
                                                "LONG_1000" -> {
                                                    success = TapAccessibilityService.performLongPressSuspend(x, y, 1000L)
                                                }
                                                "DOUBLE_TAP" -> {
                                                    val first = TapAccessibilityService.performTapSuspend(x, y)
                                                    delay(120L)
                                                    val second = TapAccessibilityService.performTapSuspend(x, y)
                                                    success = first && second
                                                }
                                                else -> { // TAP
                                                    success = TapAccessibilityService.performTapSuspend(x, y)
                                                }
                                            }
                                            val elapsed = System.currentTimeMillis() - startTime
                                            isCustomTesting = false

                                            if (success) {
                                                addDiagnosticLog("CUSTOM_$selectedGestureType", "(${x.toInt()}, ${y.toInt()})", true, elapsed, "Gestur $selectedGestureType berhasil diselesaikan oleh OS Android")
                                            } else {
                                                addDiagnosticLog("CUSTOM_$selectedGestureType", "(${x.toInt()}, ${y.toInt()})", false, elapsed, "Gestur ditolak/dibatalkan oleh OS")
                                            }
                                        }
                                    },
                                    modifier = Modifier.fillMaxWidth(),
                                    enabled = !isCustomTesting,
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = CyberCyan,
                                        contentColor = Color.Black
                                    ),
                                    shape = RoundedCornerShape(12.dp),
                                    contentPadding = PaddingValues(vertical = 12.dp)
                                ) {
                                    if (isCustomTesting) {
                                        CircularProgressIndicator(modifier = Modifier.size(18.dp), color = Color.Black, strokeWidth = 2.dp)
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text("Mengirimkan Gestur...", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                    } else {
                                        Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(18.dp))
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text("KIRIM GESTUR UJI (${inputX}px, ${inputY}px)", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                    }
                                }
                            }
                        }

                        2 -> {
                            // ================= TAB 2: VISUAL TOUCH CANVAS ARENA =================
                            Column(
                                modifier = Modifier.fillMaxSize(),
                                verticalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = "Sentuh area kanvas untuk menentukan titik:",
                                        fontSize = 11.sp,
                                        color = TextMuted
                                    )
                                    Text(
                                        text = "(${canvasSelectedX.toInt()}px, ${canvasSelectedY.toInt()}px)",
                                        fontFamily = FontFamily.Monospace,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = CyberCyan
                                    )
                                }

                                // Interactive Canvas Area
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .weight(1f)
                                        .clip(RoundedCornerShape(16.dp))
                                        .background(ConsoleBg)
                                        .border(1.dp, BorderSlate, RoundedCornerShape(16.dp))
                                        .pointerInput(Unit) {
                                            detectTapGestures { offset ->
                                                canvasSelectedX = offset.x
                                                canvasSelectedY = offset.y
                                                inputX = offset.x.toInt().toString()
                                                inputY = offset.y.toInt().toString()
                                            }
                                        }
                                ) {
                                    // Draw Grid & Crosshair
                                    Canvas(modifier = Modifier.fillMaxSize()) {
                                        val canvasWidth = size.width
                                        val canvasHeight = size.height

                                        // Subtle grid lines
                                        val gridStep = 40.dp.toPx()
                                        var gx = 0f
                                        while (gx < canvasWidth) {
                                            drawLine(
                                                color = Color(0xFF1E293B),
                                                start = Offset(gx, 0f),
                                                end = Offset(gx, canvasHeight),
                                                strokeWidth = 1f
                                            )
                                            gx += gridStep
                                        }
                                        var gy = 0f
                                        while (gy < canvasHeight) {
                                            drawLine(
                                                color = Color(0xFF1E293B),
                                                start = Offset(0f, gy),
                                                end = Offset(canvasWidth, gy),
                                                strokeWidth = 1f
                                            )
                                            gy += gridStep
                                        }

                                        // Selected Point Crosshair
                                        val cx = canvasSelectedX.coerceIn(0f, canvasWidth)
                                        val cy = canvasSelectedY.coerceIn(0f, canvasHeight)

                                        // Dashed guide lines
                                        drawLine(
                                            color = CyberCyan.copy(alpha = 0.5f),
                                            start = Offset(cx, 0f),
                                            end = Offset(cx, canvasHeight),
                                            strokeWidth = 1.5f,
                                            pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 10f), 0f)
                                        )
                                        drawLine(
                                            color = CyberCyan.copy(alpha = 0.5f),
                                            start = Offset(0f, cy),
                                            end = Offset(canvasWidth, cy),
                                            strokeWidth = 1.5f,
                                            pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 10f), 0f)
                                        )

                                        // Outer pulsing ring
                                        drawCircle(
                                            color = CyberCyan.copy(alpha = 0.3f),
                                            radius = 24.dp.toPx(),
                                            center = Offset(cx, cy)
                                        )
                                        // Inner target point
                                        drawCircle(
                                            color = EmeraldReady,
                                            radius = 6.dp.toPx(),
                                            center = Offset(cx, cy)
                                        )
                                    }

                                    Box(
                                        modifier = Modifier
                                            .align(Alignment.BottomStart)
                                            .padding(8.dp)
                                            .background(SlateCardBg.copy(alpha = 0.85f), RoundedCornerShape(6.dp))
                                            .padding(horizontal = 8.dp, vertical = 4.dp)
                                    ) {
                                        Text(
                                            "Tap di mana saja pada kotak ini",
                                            fontSize = 9.sp,
                                            color = TextMuted
                                        )
                                    }
                                }

                                // Trigger Tap at Canvas Coordinate
                                Button(
                                    onClick = {
                                        if (!TapAccessibilityService.isRunning()) {
                                            Toast.makeText(context, "Layanan Aksesibilitas belum aktif!", Toast.LENGTH_SHORT).show()
                                            addDiagnosticLog("CANVAS_TAP", "(${canvasSelectedX.toInt()}, ${canvasSelectedY.toInt()})", false, 0L, "Layanan Aksesibilitas belum berjalan")
                                            return@Button
                                        }

                                        coroutineScope.launch {
                                            val startTime = System.currentTimeMillis()
                                            val success = TapAccessibilityService.performTapSuspend(canvasSelectedX, canvasSelectedY)
                                            val elapsed = System.currentTimeMillis() - startTime

                                            if (success) {
                                                addDiagnosticLog("CANVAS_TAP", "(${canvasSelectedX.toInt()}, ${canvasSelectedY.toInt()})", true, elapsed, "Ketukan berhasil dikirim ke titik kanvas")
                                            } else {
                                                addDiagnosticLog("CANVAS_TAP", "(${canvasSelectedX.toInt()}, ${canvasSelectedY.toInt()})", false, elapsed, "Gestur gagal dikirim ke titik kanvas")
                                            }
                                        }
                                    },
                                    modifier = Modifier.fillMaxWidth(),
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = EmeraldReady,
                                        contentColor = Color.Black
                                    ),
                                    shape = RoundedCornerShape(12.dp),
                                    contentPadding = PaddingValues(vertical = 12.dp)
                                ) {
                                    Icon(Icons.Default.TouchApp, contentDescription = null, modifier = Modifier.size(18.dp))
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("UJI KETUK TITIK KANVAS (${canvasSelectedX.toInt()}px, ${canvasSelectedY.toInt()}px)", fontWeight = FontWeight.Bold, fontSize = 11.sp)
                                }
                            }
                        }
                    }
                }

                // Divider
                HorizontalDivider(color = BorderSlate, thickness = 1.dp)

                // 2. DIAGNOSTIC LOG FEEDBACK CONSOLE
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(130.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(ConsoleBg)
                        .border(1.dp, BorderSlate, RoundedCornerShape(12.dp))
                        .padding(8.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Box(
                                modifier = Modifier
                                    .size(6.dp)
                                    .clip(CircleShape)
                                    .background(if (diagnosticLogs.firstOrNull()?.isSuccess == true) EmeraldReady else CyberCyan)
                            )
                            Text(
                                "LOG RESPON GESTUR SISTEM",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        }

                        if (diagnosticLogs.isNotEmpty()) {
                            Text(
                                text = "Bersihkan",
                                fontSize = 9.sp,
                                color = CyberCyan,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.clickable { diagnosticLogs.clear() }
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    if (diagnosticLogs.isEmpty()) {
                        Box(
                            modifier = Modifier.fillMaxSize(),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                "Belum ada uji coba ketukan. Tekan salah satu tombol uji di atas.",
                                fontSize = 10.sp,
                                color = TextMuted,
                                textAlign = TextAlign.Center
                            )
                        }
                    } else {
                        LazyColumn(
                            modifier = Modifier.fillMaxSize(),
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            items(diagnosticLogs) { log ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .background(if (log.isSuccess) EmeraldReady.copy(alpha = 0.05f) else Color(0xFFEF4444).copy(alpha = 0.05f), RoundedCornerShape(4.dp))
                                        .padding(horizontal = 6.dp, vertical = 3.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Text(
                                            text = if (log.isSuccess) "✓" else "✕",
                                            color = if (log.isSuccess) EmeraldReady else Color(0xFFEF4444),
                                            fontWeight = FontWeight.Black,
                                            fontSize = 11.sp
                                        )
                                        Text(
                                            text = "[${log.timestamp}] ${log.coordinates} -> ${log.message}",
                                            fontFamily = FontFamily.Monospace,
                                            fontSize = 10.sp,
                                            color = if (log.isSuccess) TextLight else Color(0xFFFCA5A5),
                                            maxLines = 1
                                        )
                                    }
                                    Text(
                                        text = "${log.latencyMs}ms",
                                        fontFamily = FontFamily.Monospace,
                                        fontSize = 9.sp,
                                        color = TextMuted
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
